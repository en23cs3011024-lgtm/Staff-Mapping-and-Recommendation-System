# Resource Mapping

## Run the employee API and frontend

The API uses a SQLite database at `backend/data/employees.sqlite` by default. It requires Node.js 22.13 or newer. Set `EMPLOYEES_DB_FILE` to store the database elsewhere and `PORT` to change the API port.

1. In one terminal, run `npm.cmd --prefix backend start` from the project root.
2. In another terminal, run `npm.cmd --prefix frontend run dev` from the project root.

Vite forwards `/api` requests to `http://localhost:3001`. When the API is running, employee records are stored in SQLite and shared by clients of that API. If the API is unavailable, the page falls back to browser localStorage for the current browser. On an empty database, existing localStorage employee records are migrated automatically when the API connects.

The API supports employee CRUD at `/api/employees` and project CRUD at `/api/projects` (GET collection, POST collection, PUT `/:id`, and DELETE `/:id`). Project records share the same SQLite database and are validated by the API. Projects saved in the browser before the API is available are migrated automatically when they connect to an empty database.

To check the project API, run `node --test backend/tests/projects-api.test.js` from the project root. For production, run the API behind the same origin/reverse proxy as the frontend and put the database file on persistent storage with appropriate backups and access controls.
