﻿import { BrowserRouter, Navigate, Route, Routes } from "react-router-dom";
import WorkspaceLayout from "./components/WorkspaceLayout";
import Login from "./pages/Login";
import Dashboard from "./pages/Dashboard";
import Employees from "./pages/Employees";
import Projects from "./pages/Projects";
import ResourceMatching from "./pages/ResourceMatching";
import Allocations from "./pages/Allocations";
import Workload from "./pages/Workload";
import Reports from "./pages/Reports";
import EmployeeProfile from "./pages/EmployeeProfile";
import Profile from "./pages/Profile";
import { AuthProvider, useAuth } from "./auth/AuthContext";

const home = (role) => role === "Employee" ? "/employee-profile" : "/dashboard";
function Protected({ roles, children }) {
  const { user, loading } = useAuth();
  if (loading) return <div className="auth-loading">Checking your session…</div>;
  if (!user) return <Navigate to="/login" replace />;
  if (roles && !roles.includes(user.role)) return <Navigate to={home(user.role)} replace />;
  return children;
}
function WorkspaceRoute({ roles, children }) { return <Protected roles={roles}><WorkspaceLayout>{children}</WorkspaceLayout></Protected>; }
function AppRoutes() {
  const { user, loading } = useAuth();
  return <Routes>
    <Route path="/login" element={loading ? <div className="auth-loading">Checking your session…</div> : user ? <Navigate to={home(user.role)} replace /> : <Login />} />
    <Route path="/" element={loading ? <div className="auth-loading">Checking your session…</div> : user ? <Navigate to={home(user.role)} replace /> : <Navigate to="/login" replace />} />
    <Route path="/dashboard" element={<Protected roles={["Admin", "Manager"]}><WorkspaceLayout><Dashboard /></WorkspaceLayout></Protected>} />
    <Route path="/employees" element={<Protected roles={["Admin", "Manager"]}><WorkspaceLayout><Employees /></WorkspaceLayout></Protected>} />
    <Route path="/projects" element={<Protected roles={["Admin", "Manager"]}><WorkspaceLayout><Projects /></WorkspaceLayout></Protected>} />
    <Route path="/resource-matching" element={<Protected roles={["Admin", "Manager"]}><WorkspaceLayout><ResourceMatching /></WorkspaceLayout></Protected>} />
    <Route path="/allocations" element={<Protected roles={["Admin", "Manager"]}><WorkspaceLayout><Allocations /></WorkspaceLayout></Protected>} />
    <Route path="/workload" element={<Protected><WorkspaceLayout><Workload /></WorkspaceLayout></Protected>} />
    <Route path="/reports" element={<Protected roles={["Admin", "Manager"]}><WorkspaceLayout><Reports /></WorkspaceLayout></Protected>} />
    <Route path="/employee-profile" element={<Protected><WorkspaceLayout><EmployeeProfile /></WorkspaceLayout></Protected>} />
    <Route path="/employee-profile/:employeeId" element={<Protected roles={["Admin", "Manager"]}><WorkspaceLayout><EmployeeProfile /></WorkspaceLayout></Protected>} />
    <Route path="/profile" element={<Protected><WorkspaceLayout><Profile /></WorkspaceLayout></Protected>} />
    <Route path="*" element={<Navigate to={user ? home(user.role) : "/login"} replace />} />
  </Routes>;
}
export default function App() { return <AuthProvider><BrowserRouter><AppRoutes /></BrowserRouter></AuthProvider>; }
