import { apiFetch } from "../auth/api";
export function readList(key) {
  try {
    const value = JSON.parse(localStorage.getItem(key) || "[]");
    return Array.isArray(value) ? value : [];
  } catch {
    return [];
  }
}

export function writeList(key, value) {
  localStorage.setItem(key, JSON.stringify(value));
}

export function readObject(key, fallback = {}) {
  try { return { ...fallback, ...JSON.parse(localStorage.getItem(key) || "{}") }; }
  catch { return { ...fallback }; }
}

export async function fetchEmployees() { return apiFetch("/api/employees"); }

export async function fetchProjects() { return apiFetch("/api/projects"); }
export async function fetchAllocations() { return apiFetch("/api/allocations"); }
export function employeeSkills(employee) {
  if (Array.isArray(employee?.skills)) return employee.skills.map((skill) => (typeof skill === "string" ? skill : skill?.name || "").toLowerCase()).filter(Boolean);
  return String(employee?.skills || "").split(",").map((skill) => skill.trim().toLowerCase()).filter(Boolean);
}

export function downloadCSV(filename, headers, rows) {
  const content = [headers, ...rows].map((row) => row.map((cell) => `"${String(cell ?? "").replace(/"/g, '""')}"`).join(",")).join("\r\n");
  const url = URL.createObjectURL(new Blob(["\uFEFF", content], { type: "text/csv;charset=utf-8" }));
  const anchor = document.createElement("a");
  anchor.href = url;
  anchor.download = filename;
  anchor.click();
  URL.revokeObjectURL(url);
}
