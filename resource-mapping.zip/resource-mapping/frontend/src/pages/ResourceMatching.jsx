import { useEffect, useMemo, useState } from "react";
import { Link } from "react-router-dom";
import { employeeSkills, fetchEmployees, fetchProjects, readList } from "./pageData";
import "./ResourceMatching.css";

const SKILL_WEIGHT = 60;
const EXPERIENCE_WEIGHT = 25;
const CAPACITY_WEIGHT = 15;

function normalizeSkill(skill) {
  return String(skill || "").trim().toLocaleLowerCase().replace(/\s+/g, " ");
}

function projectSkills(project) {
  const values = Array.isArray(project?.requiredSkills)
    ? project.requiredSkills
    : String(project?.requiredSkills || project?.skills || "").split(",");
  return [...new Set(values.map((skill) => String(skill).trim()).filter(Boolean))];
}

function getEmployeeSkills(employee) {
  return [...new Set(employeeSkills(employee).map(normalizeSkill).filter(Boolean))];
}

function scoreEmployee(employee, project, requiredSkills, allocations) {
  const skills = getEmployeeSkills(employee);
  const matchedSkills = requiredSkills.filter((required) => skills.includes(normalizeSkill(required)));
  const missingSkills = requiredSkills.filter((required) => !skills.includes(normalizeSkill(required)));
  const experience = Math.max(0, Number(employee.experience) || 0);
  const requiredExperience = Math.max(0, Number(project?.experience) || 0);
  const experienceScore = requiredExperience === 0
    ? EXPERIENCE_WEIGHT
    : Math.min(experience / requiredExperience, 1) * EXPERIENCE_WEIGHT;
  const skillScore = requiredSkills.length ? matchedSkills.length / requiredSkills.length * SKILL_WEIGHT : 0;

  const employeeAllocations = allocations.filter((allocation) =>
    String(allocation.employeeId) === String(employee.id) && allocation.status === "Active");
  const allocationLoad = employeeAllocations.reduce((sum, allocation) => sum + (Number(allocation.allocation) || 0), 0);
  const baselineWorkload = Math.max(0, Number(employee.workload) || 0);
  const totalWorkload = baselineWorkload + allocationLoad;
  const capacity = Math.max(0, Math.min(100, 100 - totalWorkload));
  const capacityScore = capacity / 100 * CAPACITY_WEIGHT;
  const score = Math.round(skillScore + experienceScore + capacityScore);
  const availability = employee.availability || "Available";
  const unavailable = availability === "Unavailable" || availability === "On Leave";
  const overloaded = totalWorkload >= 100;
  const reasons = [];

  if (requiredSkills.length) {
    reasons.push(matchedSkills.length
      ? `Matches ${matchedSkills.length} of ${requiredSkills.length} required skills: ${matchedSkills.join(", ")}.`
      : "No required skills matched.");
    if (missingSkills.length) reasons.push(`Missing: ${missingSkills.join(", ")}.`);
  } else {
    reasons.push("Project has no required skills yet; add skills for a more useful match.");
  }
  if (requiredExperience > 0) {
    reasons.push(experience >= requiredExperience
      ? `Meets the ${requiredExperience}+ year experience requirement.`
      : `${(requiredExperience - experience).toFixed(1)} years below the ${requiredExperience}+ year requirement.`);
  } else {
    reasons.push("No minimum experience set; experience does not affect this score.");
  }
  reasons.push(`${capacity}% capacity available (${Math.round(totalWorkload)}% workload).`);
  if (unavailable) reasons.push(`Unavailable: status is ${availability.toLowerCase()}.`);
  if (overloaded) reasons.push("At or over 100% workload; do not assign additional work.");

  return {
    ...employee,
    availability,
    skills,
    matchedSkills,
    missingSkills,
    skillScore: Math.round(skillScore),
    experienceScore: Math.round(experienceScore),
    capacityScore: Math.round(capacityScore),
    score,
    baselineWorkload,
    allocationLoad,
    totalWorkload,
    capacity,
    unavailable,
    overloaded,
    reasons,
  };
}

export default function ResourceMatching() {
  const [employees, setEmployees] = useState(() => readList("employees"));
  const [projects, setProjects] = useState(() => readList("projects"));
  const [allocations, setAllocations] = useState(() => readList("allocations"));
  const [projectsLoading, setProjectsLoading] = useState(true);
  const [projectId, setProjectId] = useState("");
  const [query, setQuery] = useState("");
  const [minimumCapacity, setMinimumCapacity] = useState(0);
  const [showExcluded, setShowExcluded] = useState(false);

  useEffect(() => {
    let active = true;
    Promise.all([fetchEmployees(), fetchProjects()]).then(([employeeData, projectData]) => {
      if (!active) return;
      setEmployees(employeeData);
      setProjects(projectData);
      setProjectsLoading(false);
    });
    const refreshAllocations = () => setAllocations(readList("allocations"));
    window.addEventListener("focus", refreshAllocations);
    return () => {
      active = false;
      window.removeEventListener("focus", refreshAllocations);
    };
  }, []);

  const project = projects.find((item) => String(item.id) === String(projectId))
    || projects.find((item) => item.status === "Active")
    || projects[0]
    || null;
  const requiredSkills = projectSkills(project);
  const rankedEmployees = useMemo(() => !project ? [] : employees
    .map((employee) => scoreEmployee(employee, project, requiredSkills, allocations))
    .filter((employee) => !query || `${employee.name} ${employee.employeeId} ${employee.department} ${employee.designation} ${employee.skills.join(" ")}`.toLocaleLowerCase().includes(query.trim().toLocaleLowerCase()))
    .sort((a, b) => b.score - a.score || b.capacity - a.capacity || a.name.localeCompare(b.name)),
  [employees, project, requiredSkills, allocations, query]);

  const recommendations = rankedEmployees.filter((employee) =>
    !employee.unavailable && !employee.overloaded && employee.capacity >= Number(minimumCapacity));
  const excluded = rankedEmployees.filter((employee) => !recommendations.includes(employee));
  const strongMatches = recommendations.filter((employee) => employee.score >= 75).length;
  const unavailableCount = rankedEmployees.filter((employee) => employee.unavailable).length;
  const overloadedCount = rankedEmployees.filter((employee) => employee.overloaded && !employee.unavailable).length;
  const averageCapacity = recommendations.length
    ? Math.round(recommendations.reduce((sum, employee) => sum + employee.capacity, 0) / recommendations.length)
    : 0;

  return <main className="page-shell matching-page">
    {projectsLoading && <p className="page-notice" role="status">Loading projects...</p>}
    <header className="page-heading"><div><span className="page-eyebrow">TALENT DISCOVERY</span><h1>Resource matching</h1><p>Rank employees by skill fit, experience, availability, and workload.</p></div><Link to="/projects" className="secondary-action matching-project-link">Manage projects</Link></header>

    <section className="page-panel matching-criteria"><div><span className="page-eyebrow">MATCH CRITERIA</span><h2>{project ? project.name : projectsLoading ? "Loading projects..." : "Choose a project"}</h2><p>{project ? "Recommendations use a transparent 60 / 25 / 15 score: skills, experience, then capacity." : "Create a project first to define the skills and experience you need."}</p></div><label>Project<select className="page-select" value={project ? String(project.id) : ""} onChange={(event) => setProjectId(event.target.value)} disabled={projectsLoading || projects.length === 0}><option value="">{projectsLoading ? "Loading projects..." : "Select project"}</option>{projects.map((item) => <option key={item.id} value={String(item.id)}>{item.name}</option>)}</select></label><div className="matching-required"><span>Required skills</span><div className="tag-list">{requiredSkills.length ? requiredSkills.map((skill) => <span className="tag" key={skill}>{skill}</span>) : <small>No skills specified</small>}</div></div></section>

    <section className="page-grid metric-grid matching-metrics"><article className="metric-card"><span>Recommended</span><strong>{recommendations.length}</strong><small>Available and within capacity</small></article><article className="metric-card"><span>Strong matches</span><strong>{strongMatches}</strong><small>Score of 75% or above</small></article><article className="metric-card"><span>Unavailable</span><strong>{unavailableCount}</strong><small>Unavailable or on leave</small></article><article className="metric-card"><span>Overloaded</span><strong>{overloadedCount}</strong><small>At or above full workload</small></article></section>

    <section className="page-panel matching-results"><div className="matching-toolbar"><div><h2>Ranked recommendations</h2><span>Best fit first · {recommendations.length} eligible employees</span></div><div className="page-controls"><input className="page-input" aria-label="Search candidates" placeholder="Search employees or skills" value={query} onChange={(event) => setQuery(event.target.value)} /><label className="capacity-filter">Minimum capacity<select className="page-select" value={minimumCapacity} onChange={(event) => setMinimumCapacity(event.target.value)}><option value="0">Any</option><option value="25">25%+</option><option value="50">50%+</option><option value="75">75%+</option></select></label></div></div>
      <div className="score-legend"><strong>Score breakdown</strong><span>Skills {SKILL_WEIGHT}%</span><span>Experience {EXPERIENCE_WEIGHT}%</span><span>Capacity {CAPACITY_WEIGHT}%</span></div>
      <div className="match-list">{recommendations.map((employee, index) => <article className="match-card" key={employee.id}>
        <div className="match-identity"><span className="match-rank">#{index + 1}</span><span className="match-avatar">{employee.name.split(/\s+/).slice(0, 2).map((part) => part[0]).join("").toUpperCase()}</span><div><Link to={`/employee-profile/${encodeURIComponent(employee.id)}`}>{employee.name}</Link><small>{employee.designation || "Employee"} · {employee.department || "No department"}</small><span className={`match-availability ${employee.availability.toLowerCase().replaceAll(" ", "-")}`}>{employee.availability}</span></div></div>
        <div className="match-skills"><span>Skill coverage · {employee.skillScore}/{SKILL_WEIGHT}</span><div className="tag-list">{employee.matchedSkills.length ? employee.matchedSkills.map((skill) => <span className="tag matched-tag" key={skill}>{skill}</span>) : <small>No required skills matched</small>}</div>{employee.missingSkills.length > 0 && <small className="missing-skills">Missing: {employee.missingSkills.join(", ")}</small>}</div>
        <div className="match-experience"><span>Experience</span><strong>{employee.experience} yrs</strong><small>{employee.experienceScore}/{EXPERIENCE_WEIGHT} points</small></div>
        <div className="match-capacity"><span>{employee.capacity}%</span><small>capacity · {employee.capacityScore}/{CAPACITY_WEIGHT} pts</small><div className="progress-track"><i style={{ width: `${employee.capacity}%` }} /></div></div>
        <div className="match-score"><strong>{employee.score}</strong><small>/ 100</small></div>
        <details className="match-reasons"><summary>Why this match?</summary><ul>{employee.reasons.map((reason) => <li key={reason}>{reason}</li>)}</ul></details>
        <Link className="match-view-link" to={`/employee-profile/${encodeURIComponent(employee.id)}`}>View profile</Link>
      </article>)}{recommendations.length === 0 && <div className="empty-message">{projectsLoading ? "Loading recommendations..." : !project ? "Create a project to get started." : employees.length === 0 ? "Add employees to your directory to see recommendations." : "No employees meet the current availability and capacity criteria. Check the excluded employees below."}</div>}</div>
    </section>

    {excluded.length > 0 && <section className="page-panel excluded-panel"><button className="excluded-toggle" type="button" aria-expanded={showExcluded} onClick={() => setShowExcluded((shown) => !shown)}><span><strong>Unavailable, overloaded, or below capacity filter</strong><small>{excluded.length} employee{excluded.length === 1 ? "" : "s"} excluded from recommendations</small></span><span>{showExcluded ? "Hide" : "Show"}</span></button>{showExcluded && <div className="excluded-list">{excluded.map((employee) => <article className="excluded-row" key={employee.id}><div><Link to={`/employee-profile/${encodeURIComponent(employee.id)}`}>{employee.name}</Link><small>{employee.designation || "Employee"} · {employee.department || "No department"}</small></div><span className={`exclusion-reason ${employee.unavailable || employee.overloaded ? "blocked" : "capacity-low"}`}>{employee.unavailable ? employee.availability : employee.overloaded ? "Overloaded" : `Only ${employee.capacity}% capacity`}</span><span className="excluded-score">{employee.score}/100 match</span><details className="excluded-details"><summary>Reason</summary><ul>{employee.reasons.map((reason) => <li key={reason}>{reason}</li>)}</ul></details></article>)}</div>}</section>}
  </main>;
}
