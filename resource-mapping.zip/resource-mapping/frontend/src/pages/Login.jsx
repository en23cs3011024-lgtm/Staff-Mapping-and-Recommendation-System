﻿import { useState } from "react";
import { useNavigate } from "react-router-dom";
import { apiFetch } from "../auth/api";
import { useAuth } from "../auth/AuthContext";
import "./Login.css";

export default function Login() {
  const navigate = useNavigate();
  const { login } = useAuth();
  const [registering, setRegistering] = useState(false);
  const [selectedRole, setSelectedRole] = useState("Admin");
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [confirmPassword, setConfirmPassword] = useState("");
  const [showPassword, setShowPassword] = useState(false);
  const [error, setError] = useState("");
  const [busy, setBusy] = useState(false);
  async function submit(event) {
    event.preventDefault(); setError("");
    if (registering && password !== confirmPassword) { setError("Passwords do not match."); return; }
    if (registering && password.length < 8) { setError("Password must be at least 8 characters."); return; }
    setBusy(true);
    try {
      const result = await apiFetch(registering ? "/api/auth/register" : "/api/auth/login", { method: "POST", body: JSON.stringify({ ...(registering ? { name } : { role: selectedRole }), email, password }) });
      login(result);
      navigate(result.user.role === "Employee" ? "/employee-profile" : "/dashboard", { replace: true });
    } catch (requestError) { setError(requestError.message || "Unable to sign in. Please try again."); }
    finally { setBusy(false); }
  }
  function switchMode() { setRegistering((value) => !value); setError(""); }
  return <div className="login-page"><div className="login-card">
    <span className="page-eyebrow">TEAM PLANNING WORKSPACE</span><h1>Resource<span>Flow</span></h1>
    <h2>{registering ? "Create your account" : `${selectedRole} sign in`}</h2><p>{registering ? "Create an account to access your workspace." : `Sign in to your ${selectedRole.toLowerCase()} workspace.`}</p>
    {!registering && <div className="login-role-picker" role="group" aria-label="Choose your account role">{[["Admin", "Manage workspace"], ["Manager", "Plan team resources"], ["Employee", "View your work"]].map(([role, hint]) => <button key={role} type="button" className={`login-role-option${selectedRole === role ? " selected" : ""}`} aria-pressed={selectedRole === role} onClick={() => { setSelectedRole(role); setError(""); }}><strong>{role}</strong><small>{hint}</small></button>)}</div>}
    <form onSubmit={submit}>
      {error && <p className="error-message" role="alert">{error}</p>}
      {registering && <div className="form-group"><label htmlFor="account-name">Full name</label><input id="account-name" type="text" required minLength="2" maxLength="100" autoComplete="name" placeholder="Your name" value={name} onChange={(event) => setName(event.target.value)} /></div>}
      <div className="form-group"><label htmlFor="account-email">Email</label><input id="account-email" type="email" required maxLength="254" autoComplete="email" placeholder="you@company.com" value={email} onChange={(event) => setEmail(event.target.value)} /></div>
      <div className="form-group"><label htmlFor="account-password">Password</label><div className="password-input-wrap"><input id="account-password" type={showPassword ? "text" : "password"} required minLength={registering ? 8 : undefined} autoComplete={registering ? "new-password" : "current-password"} placeholder={registering ? "At least 8 characters" : "Enter your password"} value={password} onChange={(event) => setPassword(event.target.value)} /><button type="button" className="password-toggle" onClick={() => setShowPassword((value) => !value)}>{showPassword ? "Hide" : "Show"}</button></div></div>
      {registering && <div className="form-group"><label htmlFor="confirm-password">Confirm password</label><input id="confirm-password" type="password" required autoComplete="new-password" placeholder="Enter password again" value={confirmPassword} onChange={(event) => setConfirmPassword(event.target.value)} /></div>}
      <button type="submit" disabled={busy}>{busy ? "Please wait…" : registering ? "Create account" : "Sign in"}</button>
    </form>
    <p className="auth-switch">{registering ? "Already have an account?" : "New to ResourceFlow?"} <button type="button" onClick={switchMode}>{registering ? "Sign in" : "Create account"}</button></p>
    {registering && <small className="registration-note">The first account becomes Admin. New accounts start as Employee; an Admin can assign Manager access.</small>}
  </div></div>;
}
