import { useEffect, useMemo, useState } from "react";
import { fetchEmployees, fetchProjects, fetchAllocations } from "./pageData";
import { apiFetch } from "../auth/api";
import "./Allocations.css";

const blank = { employeeId: "", projectId: "", allocation: "25", startDate: "", endDate: "", status: "Active", notes: "" };

export default function Allocations() {
  const [allocations, setAllocations] = useState([]);
  const [employees, setEmployees] = useState([]);
  const [projects, setProjects] = useState([]);
  const [form, setForm] = useState(blank);
  const [editingId, setEditingId] = useState(null);
  const [showForm, setShowForm] = useState(false);
  const [search, setSearch] = useState("");
  const [filter, setFilter] = useState("All");
  const [error, setError] = useState("");
  useEffect(() => {
    let active = true;
    Promise.all([fetchEmployees(), fetchProjects(), fetchAllocations()])
      .then(([employeeData, projectData, allocationData]) => {
        if (!active) return;
        setEmployees(employeeData);
        setProjects(projectData);
        setAllocations(allocationData);
      })
      .catch((reason) => { if (active) setError(reason.message); });
    return () => { active = false; };
  }, []);
  const save = (next) => setAllocations(next);
  const visible = useMemo(() => allocations.filter((a) => (filter === "All" || a.status === filter) && `${a.employeeName} ${a.projectName}`.toLowerCase().includes(search.toLowerCase())).sort((a, b) => (a.employeeName || "").localeCompare(b.employeeName || "")), [allocations, filter, search]);
  function closeForm() { setShowForm(false); setForm(blank); setEditingId(null); setError(""); }
  async function submit(event) {
    event.preventDefault(); setError("");
    const allocation = Number(form.allocation);
    const employee = employees.find((item) => String(item.id) === form.employeeId);
    const project = projects.find((item) => String(item.id) === form.projectId);
    if (!employee || !project) { setError("Choose an employee and a project before saving."); return; }
    if (!Number.isFinite(allocation) || allocation < 1 || allocation > 100) { setError("Allocation must be between 1% and 100%."); return; }
    if (form.endDate && form.startDate && form.endDate < form.startDate) { setError("End date must be on or after the start date."); return; }
    const assigned = allocations.filter((item) => item.employeeId === form.employeeId && item.status === "Active" && item.id !== editingId).reduce((sum, item) => sum + Number(item.allocation), 0);
    const capacity = Math.max(0, 100 - Number(employee.workload || 0));
    if (form.status === "Active" && assigned + allocation > capacity) { setError(`This assignment would exceed ${employee.name}'s available ${capacity}% capacity. Existing active assignments total ${assigned}%.`); return; }
    const record = { ...form, allocation, employeeName: employee.name, projectName: project.name };
    try {
      const saved = await apiFetch(editingId ? `/api/allocations/${encodeURIComponent(editingId)}` : "/api/allocations", {
        method: editingId ? "PUT" : "POST",
        body: JSON.stringify(record),
      });
      save(editingId ? allocations.map((item) => item.id === editingId ? saved : item) : [saved, ...allocations]);
      closeForm();
    } catch (saveError) { setError(saveError.message); }
  }
  function edit(item) { setForm({ ...blank, ...item, employeeId: String(item.employeeId), projectId: String(item.projectId), allocation: String(item.allocation) }); setEditingId(item.id); setShowForm(true); }
  async function remove(item) {
    if (!window.confirm(`Remove ${item.employeeName}'s allocation to ${item.projectName}?`)) return;
    try {
      await apiFetch(`/api/allocations/${encodeURIComponent(item.id)}`, { method: "DELETE" });
      save(allocations.filter((record) => record.id !== item.id));
    } catch (removeError) { setError(removeError.message); }
  }
  const active = allocations.filter((item) => item.status === "Active");
  return <main className="page-shell allocations-page">
    <header className="page-heading"><div><span className="page-eyebrow">TEAM ASSIGNMENTS</span><h1>Allocations</h1><p>Assign people to projects and keep assignments within capacity.</p></div><button className="primary-action" onClick={() => { closeForm(); setShowForm(true); }}>+ New allocation</button></header>
    <section className="page-grid metric-grid"><article className="metric-card"><span>Active assignments</span><strong>{active.length}</strong><small>Currently in progress</small></article><article className="metric-card"><span>People assigned</span><strong>{new Set(active.map((item) => item.employeeId)).size}</strong><small>Unique team members</small></article><article className="metric-card"><span>Projects staffed</span><strong>{new Set(active.map((item) => item.projectId)).size}</strong><small>With active allocation</small></article><article className="metric-card"><span>Planned allocation</span><strong>{active.reduce((sum, item) => sum + Number(item.allocation || 0), 0)}%</strong><small>Combined assignment share</small></article></section>
    {showForm && <section className="page-panel allocation-form-panel"><div className="allocation-form-heading"><div><span className="page-eyebrow">ASSIGNMENT DETAILS</span><h2>{editingId ? "Edit allocation" : "Assign a team member"}</h2></div><button className="secondary-action" onClick={closeForm}>Close</button></div>{employees.length === 0 || projects.length === 0 ? <p className="page-notice">Add employees and projects before creating allocations. <a href="/employees">Employees</a> · <a href="/projects">Projects</a></p> : <form className="page-form" onSubmit={submit}><label>Employee<select className="page-select" required value={form.employeeId} onChange={(e) => setForm({ ...form, employeeId: e.target.value })}><option value="">Choose employee</option>{employees.map((employee) => <option key={employee.id} value={employee.id}>{employee.name} ({Math.max(0, 100 - Number(employee.workload || 0))}% capacity)</option>)}</select></label><label>Project<select className="page-select" required value={form.projectId} onChange={(e) => setForm({ ...form, projectId: e.target.value })}><option value="">Choose project</option>{projects.map((project) => <option key={project.id} value={project.id}>{project.name}</option>)}</select></label><label>Allocation (%)<input className="page-input" type="number" min="1" max="100" value={form.allocation} onChange={(e) => setForm({ ...form, allocation: e.target.value })} required /></label><label>Status<select className="page-select" value={form.status} onChange={(e) => setForm({ ...form, status: e.target.value })}>{["Active", "Proposed", "Completed"].map((status) => <option key={status}>{status}</option>)}</select></label><label>Start date<input className="page-input" type="date" value={form.startDate} onChange={(e) => setForm({ ...form, startDate: e.target.value })} /></label><label>End date<input className="page-input" type="date" value={form.endDate} onChange={(e) => setForm({ ...form, endDate: e.target.value })} /></label><label className="span-all">Notes<input className="page-input" value={form.notes} onChange={(e) => setForm({ ...form, notes: e.target.value })} maxLength="300" /></label>{error && <p className="page-notice error span-all" role="alert">{error}</p>}<div className="page-actions span-all"><button className="primary-action" type="submit">{editingId ? "Save allocation" : "Create allocation"}</button><button className="secondary-action" type="button" onClick={closeForm}>Cancel</button></div></form>}</section>}
    <section className="page-panel"><div className="allocation-list-heading"><div><h2>Allocation register</h2><span>{visible.length} assignments</span></div><div className="page-controls"><input className="page-input" aria-label="Search allocations" placeholder="Search people or projects" value={search} onChange={(e) => setSearch(e.target.value)} /><select className="page-select" aria-label="Filter allocation status" value={filter} onChange={(e) => setFilter(e.target.value)}><option>All</option>{["Active", "Proposed", "Completed"].map((status) => <option key={status}>{status}</option>)}</select></div></div><div className="page-table-wrap"><table className="page-table"><thead><tr><th>Employee</th><th>Project</th><th>Allocation</th><th>Dates</th><th>Status</th><th>Actions</th></tr></thead><tbody>{visible.map((item) => <tr key={item.id}><td><strong>{item.employeeName}</strong><small>{item.notes || "Team assignment"}</small></td><td>{item.projectName}</td><td><div className="allocation-value">{item.allocation}%<div className="progress-track"><i style={{ width: `${Math.min(100, Number(item.allocation))}%` }} /></div></div></td><td>{item.startDate || "Not set"}<small>to {item.endDate || "Not set"}</small></td><td><span className={`status-pill ${item.status.toLowerCase()}`}>{item.status}</span></td><td><button className="table-link" onClick={() => edit(item)}>Edit</button><button className="table-link danger-link" onClick={() => remove(item)}>Remove</button></td></tr>)}{visible.length === 0 && <tr><td className="empty-message" colSpan="6">{allocations.length ? "No assignments match." : "No allocations yet. Create an employee and project, then assign them here."}</td></tr>}</tbody></table></div></section>
  </main>;
}
