import { useEffect, useMemo, useState } from "react";
import { downloadCSV, readList, writeList } from "./pageData";
import "./Projects.css";
import { apiFetch } from "../auth/api";
import { useAuth } from "../auth/AuthContext";

const KEY = "projects";
const blank = { name: "", client: "", description: "", requiredSkills: "", experience: "", teamSize: "1", startDate: "", endDate: "", status: "Planned" };

async function requestProjects(path, options) { return apiFetch(path, options); }

function normalizeProject(project, id) {
  return {
    ...project,
    id,
    name: project.name.trim(),
    client: project.client.trim(),
    requiredSkills: project.requiredSkills.split(",").map((skill) => skill.trim()).filter(Boolean),
    experience: Number(project.experience || 0),
    teamSize: Number(project.teamSize || 1),
    updatedAt: new Date().toISOString(),
  };
}

export default function Projects() {
  const { user } = useAuth();
  const isAdmin = user?.role === "Admin";
  const [projects, setProjects] = useState(() => readList(KEY));
  const [storageMode, setStorageMode] = useState("checking");
  const [form, setForm] = useState(blank);
  const [editingId, setEditingId] = useState(null);
  const [showForm, setShowForm] = useState(false);
  const [filter, setFilter] = useState("All");
  const [search, setSearch] = useState("");
  const [error, setError] = useState("");
  const [busy, setBusy] = useState(false);

  useEffect(() => {
    let active = true;
    requestProjects("/api/projects").then(async (serverProjects) => {
      if (!active) return;
      const localProjects = readList(KEY);
      if (serverProjects.length === 0 && localProjects.length > 0) {
        try {
          const migrated = [];
          for (const project of localProjects) {
            const payload = {
              ...project,
              requiredSkills: Array.isArray(project.requiredSkills) ? project.requiredSkills : String(project.requiredSkills || project.skills || "").split(",").map((skill) => skill.trim()).filter(Boolean),
              teamSize: Number(project.teamSize) || 1,
              experience: Number(project.experience) || 0,
              status: project.status || "Planned",
            };
            delete payload.id;
            migrated.push(await requestProjects("/api/projects", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(payload) }));
          }
          if (active) { setProjects(migrated); setStorageMode("server"); }
        } catch {
          if (active) { setProjects(localProjects); setStorageMode("local"); }
        }
      } else {
        setProjects(serverProjects);
        setStorageMode("server");
      }
    }).catch(() => {
      if (active) { setProjects(readList(KEY)); setStorageMode("local"); }
    });
    return () => { active = false; };
  }, []);

  const visible = useMemo(() => projects
    .filter((project) => (filter === "All" || project.status === filter) && `${project.name} ${project.client} ${Array.isArray(project.requiredSkills) ? project.requiredSkills.join(" ") : project.requiredSkills}`.toLowerCase().includes(search.trim().toLowerCase()))
    .sort((a, b) => (a.name || "").localeCompare(b.name || "")), [projects, filter, search]);
  const activeProjects = projects.filter((project) => project.status === "Active").length;
  const plannedProjects = projects.filter((project) => project.status === "Planned").length;
  const completedProjects = projects.filter((project) => project.status === "Completed").length;

  function closeForm() { setShowForm(false); setEditingId(null); setForm(blank); setError(""); }
  function startNewProject() { closeForm(); setError(""); setShowForm(true); }

  async function submit(event) {
    event.preventDefault();
    setError("");
    if (form.endDate && form.startDate && form.endDate < form.startDate) { setError("End date must be on or after the start date."); return; }
    const id = editingId || globalThis.crypto?.randomUUID?.() || String(Date.now());
    const project = normalizeProject(form, id);
    setBusy(true);
    try {
      if (storageMode === "server") {
        const saved = await requestProjects(editingId ? `/api/projects/${encodeURIComponent(editingId)}` : "/api/projects", {
          method: editingId ? "PUT" : "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify(project),
        });
        setProjects((current) => editingId ? current.map((item) => item.id === editingId ? saved : item) : [saved, ...current]);
      } else {
        setProjects((current) => {
          const next = editingId ? current.map((item) => item.id === editingId ? project : item) : [project, ...current];
          writeList(KEY, next);
          return next;
        });
      }
      closeForm();
    } catch (saveError) {
      setError(saveError.message);
    } finally {
      setBusy(false);
    }
  }

  function edit(project) {
    setForm({ ...blank, ...project, requiredSkills: Array.isArray(project.requiredSkills) ? project.requiredSkills.join(", ") : project.requiredSkills || "", experience: String(project.experience ?? ""), teamSize: String(project.teamSize ?? 1) });
    setEditingId(project.id);
    setError("");
    setShowForm(true);
  }

  async function remove(project) {
    if (!window.confirm(`Delete project "${project.name}"? This cannot be undone.`)) return;
    setError("");
    try {
      if (storageMode === "server") await requestProjects(`/api/projects/${encodeURIComponent(project.id)}`, { method: "DELETE" });
      setProjects((current) => {
        const next = current.filter((item) => item.id !== project.id);
        if (storageMode !== "server") writeList(KEY, next);
        return next;
      });
    } catch (deleteError) {
      setError(deleteError.message);
    }
  }

  const exportVisible = () => downloadCSV("projects.csv", ["Project", "Client", "Status", "Skills", "Experience", "Team size", "Start", "End"], visible.map((project) => [project.name, project.client, project.status, Array.isArray(project.requiredSkills) ? project.requiredSkills.join("; ") : project.requiredSkills, project.experience, project.teamSize, project.startDate, project.endDate]));

  return <main className="page-shell projects-page">
    <header className="page-heading"><div><span className="page-eyebrow">DELIVERY PLANNING</span><h1>Projects</h1><p>Define project demand, skills, timeline, and status.</p></div><div className="page-actions"><span className={`project-storage-status ${storageMode}`} role="status">{storageMode === "server" ? "SQLite connected" : storageMode === "local" ? "Browser storage" : "Connecting..."}</span><button className="secondary-action" onClick={exportVisible} disabled={visible.length === 0}>Export CSV</button>{isAdmin && <button className="primary-action" onClick={startNewProject} disabled={storageMode === "checking"}>+ New project</button>}</div></header>
    {error && !showForm && <p className="page-notice error" role="alert">{error}</p>}
    {storageMode === "local" && <p className="project-storage-notice">API is unavailable. Changes are saved only in this browser and will not automatically sync to SQLite.</p>}
    <section className="page-grid metric-grid"><article className="metric-card"><span>Total projects</span><strong>{projects.length}</strong><small>Across all statuses</small></article><article className="metric-card"><span>Active</span><strong>{activeProjects}</strong><small>Currently in delivery</small></article><article className="metric-card"><span>Planned</span><strong>{plannedProjects}</strong><small>Awaiting kickoff</small></article><article className="metric-card"><span>Completed</span><strong>{completedProjects}</strong><small>Delivered projects</small></article></section>
    {showForm && <section className="page-panel project-form-panel"><div className="form-panel-title"><div><span className="page-eyebrow">PROJECT DETAILS</span><h2>{editingId ? "Edit project" : "Create a project"}</h2></div><button className="secondary-action" type="button" onClick={closeForm}>Close</button></div><form className="page-form" onSubmit={submit}><label>Project name *<input className="page-input" value={form.name} onChange={(event) => setForm({ ...form, name: event.target.value })} required maxLength="120" /></label><label>Client / team<input className="page-input" value={form.client} onChange={(event) => setForm({ ...form, client: event.target.value })} maxLength="120" /></label><label className="span-all">Description<textarea className="page-textarea" rows="3" value={form.description} onChange={(event) => setForm({ ...form, description: event.target.value })} maxLength="1000" /></label><label className="span-all">Required skills (comma separated)<input className="page-input" value={form.requiredSkills} onChange={(event) => setForm({ ...form, requiredSkills: event.target.value })} placeholder="React, SQL, UX design" /></label><label>Minimum experience (years)<input className="page-input" type="number" min="0" max="80" step="0.5" value={form.experience} onChange={(event) => setForm({ ...form, experience: event.target.value })} /></label><label>Team size<input className="page-input" type="number" min="1" max="500" value={form.teamSize} onChange={(event) => setForm({ ...form, teamSize: event.target.value })} required /></label><label>Start date<input className="page-input" type="date" value={form.startDate} onChange={(event) => setForm({ ...form, startDate: event.target.value })} /></label><label>End date<input className="page-input" type="date" value={form.endDate} onChange={(event) => setForm({ ...form, endDate: event.target.value })} /></label><label>Status<select className="page-select" value={form.status} onChange={(event) => setForm({ ...form, status: event.target.value })}>{["Planned", "Active", "On Hold", "At Risk", "Completed"].map((status) => <option key={status}>{status}</option>)}</select></label>{error && <p className="page-notice error span-all" role="alert">{error}</p>}<div className="page-actions span-all"><button className="primary-action" type="submit" disabled={busy}>{busy ? "Saving..." : editingId ? "Save project" : "Create project"}</button><button className="secondary-action" type="button" onClick={closeForm} disabled={busy}>Cancel</button></div></form></section>}
    <section className="page-panel"><div className="project-list-header"><div><h2>Project directory</h2><span>{visible.length} projects</span></div><div className="page-controls"><input className="page-input" placeholder="Search projects" aria-label="Search projects" value={search} onChange={(event) => setSearch(event.target.value)} /><select className="page-select" aria-label="Filter by status" value={filter} onChange={(event) => setFilter(event.target.value)}><option value="All">All statuses</option>{["Planned", "Active", "On Hold", "At Risk", "Completed"].map((status) => <option key={status}>{status}</option>)}</select></div></div><div className="page-table-wrap"><table className="page-table"><thead><tr><th>Project</th><th>Skills</th><th>Timeline</th><th>Team</th><th>Status</th><th>Actions</th></tr></thead><tbody>{visible.map((project) => <tr key={project.id}><td><strong>{project.name}</strong><small>{project.client || project.description || "No client details"}</small></td><td><div className="tag-list">{(Array.isArray(project.requiredSkills) ? project.requiredSkills : String(project.requiredSkills || "").split(",")).map((skill) => skill.trim()).filter(Boolean).map((skill) => <span className="tag" key={skill}>{skill}</span>)}</div></td><td>{project.startDate || "Not set"}<small>to {project.endDate || "Not set"}</small></td><td>{project.teamSize || 1} people<small>{project.experience || 0}+ years experience</small></td><td><span className={`status-pill ${(project.status || "Planned").toLowerCase().replaceAll(" ", "-")}`}>{project.status || "Planned"}</span></td><td>{isAdmin && <><button className="table-link" onClick={() => edit(project)}>Edit</button><button className="table-link danger-link" onClick={() => remove(project)}>Delete</button></>}</td></tr>)}{visible.length === 0 && <tr><td className="empty-message" colSpan="6">{storageMode === "checking" ? "Loading projects..." : projects.length ? "No projects match your search." : "No projects yet. Create one to start planning demand."}</td></tr>}</tbody></table></div></section>
  </main>;
}
