import { useEffect, useMemo, useRef, useState } from "react";
import "./Employees.css";
import { apiFetch } from "../auth/api";
import { useAuth } from "../auth/AuthContext";

const STORAGE_KEY = "employees";
const emptyEmployee = {
  name: "", employeeId: "", email: "", phone: "", department: "", designation: "",
  joiningDate: "", skills: [], skillLevel: "Intermediate", certifications: "",
  experience: "", availability: "Available", projects: "0", workload: "0", leaveUntil: "",
};

function skillText(skills) {
  if (Array.isArray(skills)) return skills.map((skill) => `${skill.name} (${skill.level}, ${skill.years} yrs)`).join("; ");
  return skills || "";
}

function skillEntries(skills) {
  if (Array.isArray(skills)) return skills.map((skill) => ({ name: skill.name || "", level: skill.level || "Intermediate", years: String(skill.years ?? 0) }));
  return String(skills || "").split(",").map((name) => name.trim()).filter(Boolean).map((name) => ({ name, level: "Intermediate", years: "0" }));
}

function skillNames(skills) {
  if (Array.isArray(skills)) return skills.map((skill) => skill.name).join(", ");
  return skills || "";
}

function readLocalEmployees() {
  try { return JSON.parse(localStorage.getItem(STORAGE_KEY) || "[]"); }
  catch { return []; }
}

function Employees() {
  const { user } = useAuth();
  const isAdmin = user?.role === "Admin";
  const [employees, setEmployees] = useState(readLocalEmployees);
  const [storageMode, setStorageMode] = useState("checking");
  const [showForm, setShowForm] = useState(false);
  const [editingId, setEditingId] = useState(null);
  const [selectedEmployee, setSelectedEmployee] = useState(null);
  const [form, setForm] = useState(emptyEmployee);
  const [error, setError] = useState("");
  const [isSaving, setIsSaving] = useState(false);
  const [searchTerm, setSearchTerm] = useState("");
  const [availabilityFilter, setAvailabilityFilter] = useState("All");
  const [departmentFilter, setDepartmentFilter] = useState("All");
  const [experienceFilter, setExperienceFilter] = useState("All");
  const [sortBy, setSortBy] = useState("name");
  const [currentPage, setCurrentPage] = useState(1);
  const pageSize = 8;

  useEffect(() => {
    let alive = true;
    apiFetch("/api/employees").then((data) => {
      if (!alive || !Array.isArray(data)) return;
      const localEmployees = readLocalEmployees();
      if (isAdmin && data.length === 0 && localEmployees.length > 0) {
        const migrate = async () => {
          const migrated = [];
          for (const employee of localEmployees) {
            const payload = { ...emptyEmployee, ...employee, employeeId: employee.employeeId || `LEGACY-${employee.id}`, id: undefined, experience: Number(employee.experience) || 0, projects: Number(employee.projects) || 0, workload: Number(employee.workload) || 0, skills: Array.isArray(employee.skills) ? employee.skills : String(employee.skills || "").split(",").map((name) => name.trim()).filter(Boolean).map((name) => ({ name, level: employee.skillLevel || "Intermediate", years: 0 })) };
            const created = await apiFetch("/api/employees", { method: "POST", body: JSON.stringify(payload) });
            migrated.push(created);
          }
          return migrated;
        };
        migrate().then((migrated) => { if (alive) { setEmployees(migrated); setStorageMode("server"); } }).catch(() => { if (alive) setStorageMode("local"); });
      } else {
        setEmployees(data);
        setStorageMode("server");
      }
    }).catch(() => { if (alive) setStorageMode("local"); });
    return () => { alive = false; };
  }, []);

  useEffect(() => {
    if (storageMode === "local") localStorage.setItem(STORAGE_KEY, JSON.stringify(employees));
  }, [employees, storageMode]);

  const departments = useMemo(() => [...new Set(employees.map((employee) => employee.department).filter(Boolean))].sort(), [employees]);
  const filteredEmployees = useMemo(() => {
    const query = searchTerm.trim().toLowerCase();
    return employees.filter((employee) => {
      const searchable = [employee.name, employee.employeeId, employee.email, employee.phone, employee.department, employee.designation, skillNames(employee.skills), employee.certifications].join(" ").toLowerCase();
      const years = Number(employee.experience) || 0;
      return (!query || searchable.includes(query)) &&
        (availabilityFilter === "All" || employee.availability === availabilityFilter) &&
        (departmentFilter === "All" || employee.department === departmentFilter) &&
        (experienceFilter === "All" || (experienceFilter === "0-2" && years <= 2) || (experienceFilter === "3-5" && years > 2 && years <= 5) || (experienceFilter === "5+" && years > 5));
    }).sort((a, b) => sortBy === "experience" ? Number(b.experience) - Number(a.experience) : sortBy === "department" ? (a.department || "").localeCompare(b.department || "") : (a.name || "").localeCompare(b.name || ""));
  }, [employees, searchTerm, availabilityFilter, departmentFilter, experienceFilter, sortBy]);
  const totalPages = Math.max(1, Math.ceil(filteredEmployees.length / pageSize));
  const currentEmployees = filteredEmployees.slice((currentPage - 1) * pageSize, currentPage * pageSize);

  useEffect(() => { setCurrentPage(1); }, [searchTerm, availabilityFilter, departmentFilter, experienceFilter]);
  useEffect(() => { if (currentPage > totalPages) setCurrentPage(totalPages); }, [currentPage, totalPages]);

  async function saveEmployee(employee, isNew) {
    if (storageMode === "checking") throw new Error("Employee data is still loading. Please try again in a moment.");
    if (storageMode === "local") {
      setEmployees((current) => isNew ? [...current, employee] : current.map((item) => String(item.id) === String(employee.id) ? employee : item));
      return;
    }
    const result = await apiFetch(isNew ? "/api/employees" : `/api/employees/${encodeURIComponent(employee.id)}`, { method: isNew ? "POST" : "PUT", body: JSON.stringify(employee) });
    setEmployees((current) => isNew ? [...current, result] : current.map((item) => String(item.id) === String(result.id) ? result : item));
  }

  async function handleSubmit(event) {
    event.preventDefault(); setError("");
    if (storageMode === "checking") { setError("Employee data is still loading. Please wait a moment, then save again."); return; }
    const enteredSkills = form.skills.filter((skill) => skill.name.trim() || skill.years !== "0");
    const skills = enteredSkills.map((skill) => ({ name: skill.name.trim(), level: skill.level, years: skill.years === "" ? NaN : Number(skill.years) }));
    if (skills.some((skill) => !skill.name || !["Beginner", "Intermediate", "Advanced", "Expert"].includes(skill.level) || !Number.isFinite(skill.years) || skill.years < 0 || skill.years > 80)) { setError("Each skill needs a name, a valid level, and 0–80 years of experience."); return; }
    const employeeData = { ...form, name: form.name.trim(), employeeId: form.employeeId.trim(), email: form.email.trim().toLowerCase(), phone: form.phone.trim(), department: form.department.trim(), designation: form.designation.trim(), skills, certifications: form.certifications.trim(), experience: Number(form.experience), projects: Number(form.projects), workload: Number(form.workload) };
    const duplicateId = employees.some((employee) => employee.employeeId?.toLowerCase() === employeeData.employeeId.toLowerCase() && employee.id !== editingId);
    const duplicateEmail = employees.some((employee) => employee.email?.toLowerCase() === employeeData.email && employee.id !== editingId);
    if (duplicateId) { setError("This employee ID is already in use. Enter a unique ID."); return; }
    if (duplicateEmail) { setError("This email is already registered. Enter a unique email."); return; }
    if (!Number.isFinite(employeeData.experience) || employeeData.experience < 0 || employeeData.experience > 80) { setError("Experience must be between 0 and 80 years."); return; }
    if (!/^\S+@\S+\.\S+$/.test(employeeData.email)) { setError("Enter a valid email address."); return; }
    if (!Number.isInteger(employeeData.projects) || employeeData.projects < 0 || !Number.isFinite(employeeData.workload) || employeeData.workload < 0 || employeeData.workload > 100) { setError("Projects must be 0 or more, and workload must be between 0% and 100%."); return; }
    setIsSaving(true);
    try {
      const isNew = editingId === null;
      await saveEmployee({ id: editingId ?? (globalThis.crypto?.randomUUID?.() || String(Date.now())), ...employeeData }, isNew);
      closeForm();
    } catch (saveError) { setError(saveError.message); }
    finally { setIsSaving(false); }
  }

  function closeForm() { setForm(emptyEmployee); setEditingId(null); setShowForm(false); setError(""); }
  function editEmployee(employee) { setForm({ ...emptyEmployee, ...employee, skills: skillEntries(employee.skills), experience: String(employee.experience ?? ""), projects: String(employee.projects ?? 0), workload: String(employee.workload ?? 0) }); setEditingId(employee.id); setShowForm(true); setSelectedEmployee(null); }
  async function deleteEmployee(employee) {
    if (!window.confirm(`Delete ${employee.name}?`)) return;
    if (storageMode === "server") {
      try { await apiFetch(`/api/employees/${encodeURIComponent(employee.id)}`, { method: "DELETE" }); }
      catch (deleteError) { setError(deleteError.message); return; }
    }
    setEmployees((current) => current.filter((item) => String(item.id) !== String(employee.id)));
    if (String(selectedEmployee?.id) === String(employee.id)) setSelectedEmployee(null);
  }

  function exportToCSV() {
    const headers = ["Employee ID", "Name", "Email", "Phone", "Department", "Designation", "Joining Date", "Skills", "Skill Level", "Experience", "Certifications", "Projects", "Workload %", "Availability", "Leave Until"];
    const rows = filteredEmployees.map((e) => [e.employeeId, e.name, e.email, e.phone, e.department, e.designation, e.joiningDate, skillText(e.skills), e.skillLevel, e.experience, e.certifications, e.projects, e.workload, e.availability, e.leaveUntil]);
    const csv = [headers, ...rows].map((row) => row.map((value) => `"${String(value ?? "").replace(/"/g, '""')}"`).join(",")).join("\r\n");
    const url = URL.createObjectURL(new Blob(["\uFEFF", csv], { type: "text/csv;charset=utf-8" }));
    const link = document.createElement("a"); link.href = url; link.download = "employees.csv"; link.click(); URL.revokeObjectURL(url);
  }

  return <main className="employee-page">
    <header className="employee-header"><div><span className="eyebrow">PEOPLE DIRECTORY</span><h1>Employee Management</h1><p>Manage employee profiles, skills, capacity, and availability.</p></div><div className="employee-header-actions"><span className={`storage-status ${storageMode}`}>{storageMode === "server" ? "● Connected to database" : storageMode === "local" ? "● Local browser storage" : "Connecting…"}</span><button className="export-csv-btn" onClick={exportToCSV}>Export CSV</button>{isAdmin && <button className="add-employee-btn" onClick={() => { closeForm(); setShowForm(true); }}>+ Add employee</button>}</div></header>
    <section className="employee-stats" aria-label="Employee statistics">
      {[ ["Total employees", employees.length], ["Available", employees.filter((e) => e.availability === "Available").length], ["On leave", employees.filter((e) => e.availability === "On Leave").length], ["Average workload", `${employees.length ? Math.round(employees.reduce((sum, e) => sum + Number(e.workload || 0), 0) / employees.length) : 0}%`] ].map(([label, value]) => <article className="employee-stat-card" key={label}><h2>{label}</h2><p>{value}</p></article>)}
    </section>
    {error && !showForm && <p className="employee-error" role="alert">{error}</p>}
    {showForm && <section className="employee-form-panel" ref={formPanelRef}><div className="section-heading"><div><span className="eyebrow">EMPLOYEE PROFILE</span><h2>{editingId !== null ? "Edit employee" : "Add employee"}</h2></div><button className="quiet-button" type="button" onClick={closeForm}>Close</button></div>
      <form className="employee-form" onSubmit={handleSubmit}>
        <h3>Personal and job details</h3>
        <label>Full name *<input value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} required maxLength="100" autoComplete="name" /></label>
        <label>Employee ID *<input value={form.employeeId} onChange={(e) => setForm({ ...form, employeeId: e.target.value })} required maxLength="40" /></label>
        <label>Email *<input type="email" value={form.email} onChange={(e) => setForm({ ...form, email: e.target.value })} required maxLength="254" autoComplete="email" /></label>
        <label>Phone<input type="tel" value={form.phone} onChange={(e) => setForm({ ...form, phone: e.target.value })} maxLength="30" autoComplete="tel" /></label>
        <label>Department<input value={form.department} onChange={(e) => setForm({ ...form, department: e.target.value })} maxLength="80" /></label>
        <label>Designation<input value={form.designation} onChange={(e) => setForm({ ...form, designation: e.target.value })} maxLength="100" /></label>
        <label>Joining date<input type="date" value={form.joiningDate} onChange={(e) => setForm({ ...form, joiningDate: e.target.value })} /></label>
        <label>Experience (years) *<input type="number" min="0" max="80" step="0.5" value={form.experience} onChange={(e) => setForm({ ...form, experience: e.target.value })} required /></label>
        <h3>Skills and experience</h3>
        <div className="wide-field skill-editor"><div className="skill-editor-heading"><div><span className="field-label">Skills</span><span className="field-hint">Track a level and experience for every skill.</span></div><button className="quiet-button" type="button" onClick={() => setForm({ ...form, skills: [...form.skills, { name: "", level: "Intermediate", years: "0" }] })}>+ Add skill</button></div>{form.skills.length === 0 && <p className="skill-empty">No skills added yet. Add a skill to build this employee's profile.</p>}{form.skills.map((skill, index) => <div className="skill-editor-row" key={`skill-${index}`}><label>Skill name<input value={skill.name} placeholder="e.g. React" onChange={(e) => setForm({ ...form, skills: form.skills.map((item, i) => i === index ? { ...item, name: e.target.value } : item) })} maxLength="80" /></label><label>Level<select value={skill.level} onChange={(e) => setForm({ ...form, skills: form.skills.map((item, i) => i === index ? { ...item, level: e.target.value } : item) })}><option>Beginner</option><option>Intermediate</option><option>Advanced</option><option>Expert</option></select></label><label>Years<input type="number" min="0" max="80" step="0.5" value={skill.years} onChange={(e) => setForm({ ...form, skills: form.skills.map((item, i) => i === index ? { ...item, years: e.target.value } : item) })} /></label><button type="button" className="remove-skill" aria-label={`Remove ${skill.name || "skill"}`} onClick={() => setForm({ ...form, skills: form.skills.filter((_, i) => i !== index) })}>Remove</button></div>)}</div>
        <label className="wide-field">Certifications<input value={form.certifications} onChange={(e) => setForm({ ...form, certifications: e.target.value })} placeholder="AWS Solutions Architect, PMP" maxLength="500" /></label>
        <h3>Availability and workload</h3>
        <label>Active projects<input type="number" min="0" step="1" value={form.projects} onChange={(e) => setForm({ ...form, projects: e.target.value })} /></label>
        <label>Workload (%)<input type="number" min="0" max="100" step="1" value={form.workload} onChange={(e) => setForm({ ...form, workload: e.target.value })} /></label>
        <label>Availability<select value={form.availability} onChange={(e) => setForm({ ...form, availability: e.target.value })}><option>Available</option><option>Partially Available</option><option>Unavailable</option><option>On Leave</option></select></label>
        <label>Leave until<input type="date" value={form.leaveUntil} onChange={(e) => setForm({ ...form, leaveUntil: e.target.value })} /></label>
        {error && <p className="employee-error wide-field" role="alert">{error}</p>}
        <div className="form-actions wide-field"><button className="add-employee-btn" type="submit" disabled={isSaving || storageMode === "checking"}>{isSaving ? "Saving..." : editingId !== null ? "Save changes" : "Add employee"}</button><button className="quiet-button" type="button" onClick={closeForm}>Cancel</button></div>
      </form>
    </section>}
    <section className="employee-table-section"><div className="section-heading"><div><span className="eyebrow">TEAM</span><h2>Employee directory</h2></div><span className="result-count">{filteredEmployees.length} employees</span></div>
      <div className="employee-controls"><input className="employee-search" value={searchTerm} onChange={(e) => setSearchTerm(e.target.value)} placeholder="Search name, ID, email, skills…" aria-label="Search employees"/><select aria-label="Filter department" value={departmentFilter} onChange={(e) => setDepartmentFilter(e.target.value)}><option value="All">All departments</option>{departments.map((department) => <option key={department}>{department}</option>)}</select><select aria-label="Filter availability" value={availabilityFilter} onChange={(e) => setAvailabilityFilter(e.target.value)}><option value="All">All availability</option>{["Available", "Partially Available", "Unavailable", "On Leave"].map((status) => <option key={status}>{status}</option>)}</select><select aria-label="Filter experience" value={experienceFilter} onChange={(e) => setExperienceFilter(e.target.value)}><option value="All">All experience</option><option value="0-2">0–2 years</option><option value="3-5">3–5 years</option><option value="5+">Above 5 years</option></select><select aria-label="Sort employees" value={sortBy} onChange={(e) => setSortBy(e.target.value)}><option value="name">Name (A–Z)</option><option value="department">Department</option><option value="experience">Experience</option></select></div>
      <div className="employee-table-wrap"><table><thead><tr><th>Employee</th><th>Department / role</th><th>Experience</th><th>Skills</th><th>Workload</th><th>Availability</th><th>Actions</th></tr></thead><tbody>{currentEmployees.map((employee) => <tr key={employee.id}><td><button className="employee-name-link" onClick={() => setSelectedEmployee(employee)}>{employee.name}</button><small>{employee.employeeId} · {employee.email}</small></td><td>{employee.department || "—"}<small>{employee.designation || "Role not set"}</small></td><td>{employee.experience} yrs</td><td>{skillNames(employee.skills) || "—"}<small>{Array.isArray(employee.skills) ? `${employee.skills.length} skills` : "Legacy skills"}</small></td><td><div className="workload-cell"><span>{employee.workload || 0}%</span><div className="workload-track"><i style={{ width: `${Math.min(100, Number(employee.workload) || 0)}%` }} /></div><small>{employee.projects || 0} projects</small></div></td><td><span className={`availability-badge ${employee.availability.toLowerCase().replaceAll(" ", "-")}`}>{employee.availability}</span>{employee.leaveUntil && employee.availability === "On Leave" && <small>Until {employee.leaveUntil}</small>}</td><td className="action-cell"><button className="row-action" onClick={() => setSelectedEmployee(employee)}>View</button>{isAdmin && <><button className="row-action" onClick={() => editEmployee(employee)}>Edit</button><button className="row-action danger" onClick={() => deleteEmployee(employee)}>Delete</button></>}</td></tr>)}{currentEmployees.length === 0 && <tr><td className="empty-state" colSpan="7">{employees.length ? "No employees match these filters." : "No employees yet. Add your first employee to get started."}</td></tr>}</tbody></table></div>
      <div className="pagination"><span>Page {currentPage} of {totalPages}</span><div><button onClick={() => setCurrentPage((page) => Math.max(1, page - 1))} disabled={currentPage === 1}>Previous</button><button onClick={() => setCurrentPage((page) => Math.min(totalPages, page + 1))} disabled={currentPage === totalPages}>Next</button></div></div>
    </section>
    {selectedEmployee && <div className="employee-modal-backdrop" onMouseDown={(event) => { if (event.target === event.currentTarget) setSelectedEmployee(null); }}><section className="employee-detail-modal" role="dialog" aria-modal="true" aria-labelledby="employee-detail-title"><button className="modal-close" onClick={() => setSelectedEmployee(null)} aria-label="Close profile">×</button><span className="eyebrow">EMPLOYEE PROFILE</span><h2 id="employee-detail-title">{selectedEmployee.name}</h2><p className="detail-subtitle">{selectedEmployee.designation || "Employee"} · {selectedEmployee.department || "Department not set"}</p><dl>{[["Employee ID", selectedEmployee.employeeId], ["Email", selectedEmployee.email], ["Phone", selectedEmployee.phone], ["Joined", selectedEmployee.joiningDate], ["Experience", `${selectedEmployee.experience} years`], ["Skills", Array.isArray(selectedEmployee.skills) ? selectedEmployee.skills.map((skill) => `${skill.name} (${skill.level}, ${skill.years} yrs)`).join(" · ") : selectedEmployee.skills], ["Certifications", selectedEmployee.certifications], ["Active projects", selectedEmployee.projects], ["Workload", `${selectedEmployee.workload}%`], ["Available capacity", `${Math.max(0, 100 - (Number(selectedEmployee.workload) || 0))}%`], ["Availability", selectedEmployee.availability], ["Leave until", selectedEmployee.leaveUntil]].map(([label, value]) => <div key={label}><dt>{label}</dt><dd>{value || "—"}</dd></div>)}</dl><div className="form-actions"><button className="add-employee-btn" onClick={() => editEmployee(selectedEmployee)}>Edit profile</button><button className="quiet-button" onClick={() => setSelectedEmployee(null)}>Close</button></div></section></div>}
  </main>;
}

export default Employees;
