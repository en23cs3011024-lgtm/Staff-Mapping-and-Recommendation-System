import { useEffect, useMemo, useState } from "react";
import { fetchEmployees, readList } from "./pageData";
import "./Workload.css";

export default function Workload() {
  const [employees, setEmployees] = useState(() => readList("employees"));
  const [allocations, setAllocations] = useState(() => readList("allocations"));
  const [department, setDepartment] = useState("All");
  const [query, setQuery] = useState("");
  useEffect(() => { let active = true; fetchEmployees().then((data) => { if (active) setEmployees(data); }); return () => { active = false; }; }, []);
  useEffect(() => { const refresh = () => setAllocations(readList("allocations")); window.addEventListener("focus", refresh); return () => window.removeEventListener("focus", refresh); }, []);
  const departments = [...new Set(employees.map((employee) => employee.department).filter(Boolean))].sort();
  const workloadRows = useMemo(() => employees.map((employee) => {
    const assigned = allocations.filter((item) => item.employeeId === employee.id && item.status === "Active");
    const base = Number(employee.workload) || 0;
    const allocated = assigned.reduce((sum, item) => sum + Number(item.allocation || 0), 0);
    const total = Math.min(100, base + allocated);
    return { ...employee, assigned, total, capacity: Math.max(0, 100 - total), totalProjects: Number(employee.projects || 0) + assigned.length };
  }).filter((employee) => (department === "All" || employee.department === department) && `${employee.name} ${employee.department} ${employee.designation}`.toLowerCase().includes(query.toLowerCase())).sort((a, b) => b.total - a.total), [employees, allocations, department, query]);
  const avg = workloadRows.length ? Math.round(workloadRows.reduce((sum, employee) => sum + employee.total, 0) / workloadRows.length) : 0;
  return <main className="page-shell workload-page">
    <header className="page-heading"><div><span className="page-eyebrow">CAPACITY PLANNING</span><h1>Workload</h1><p>Spot overloaded teammates and available capacity before planning new work.</p></div></header>
    <section className="page-grid metric-grid"><article className="metric-card"><span>Average workload</span><strong>{avg}%</strong><small>Across {workloadRows.length} team members</small></article><article className="metric-card"><span>At capacity</span><strong>{workloadRows.filter((employee) => employee.total >= 100).length}</strong><small>100% assigned or more</small></article><article className="metric-card"><span>Available capacity</span><strong>{workloadRows.reduce((sum, employee) => sum + employee.capacity, 0)}%</strong><small>Combined team capacity</small></article><article className="metric-card"><span>Active assignments</span><strong>{allocations.filter((item) => item.status === "Active").length}</strong><small>Tracked across projects</small></article></section>
    <section className="page-panel"><div className="workload-list-heading"><div><h2>Team capacity</h2><span>Workload combines employee baseline and active allocations.</span></div><div className="page-controls"><input className="page-input" aria-label="Search team" placeholder="Search team" value={query} onChange={(e) => setQuery(e.target.value)} /><select className="page-select" aria-label="Filter department" value={department} onChange={(e) => setDepartment(e.target.value)}><option>All</option>{departments.map((item) => <option key={item}>{item}</option>)}</select></div></div><div className="workload-list">{workloadRows.map((employee) => <article className="workload-row" key={employee.id}><div className="workload-person"><span className="workload-avatar">{employee.name.split(/\s+/).slice(0, 2).map((part) => part[0]).join("").toUpperCase()}</span><div><strong>{employee.name}</strong><small>{employee.designation || "Employee"} · {employee.department || "No department"}</small></div></div><div className="workload-main"><div className="workload-bar-label"><span>Assigned workload</span><strong>{employee.total}%</strong></div><div className={`workload-large-track ${employee.total >= 100 ? "overloaded" : employee.total >= 80 ? "busy" : ""}`}><i style={{ width: `${employee.total}%` }} /></div><small>{employee.totalProjects} projects · {employee.capacity}% capacity left</small></div><div className="workload-assignment-list">{employee.assigned.length ? employee.assigned.map((item) => <span key={item.id}>{item.projectName} <b>{item.allocation}%</b></span>) : <span>No active allocations</span>}</div><span className={`capacity-state ${employee.total >= 100 ? "full" : employee.total >= 80 ? "busy" : "open"}`}>{employee.total >= 100 ? "At capacity" : employee.total >= 80 ? "High workload" : "Available"}</span></article>)}{workloadRows.length === 0 && <div className="empty-message">No team members match this filter.</div>}</div></section>
  </main>;
}
