import { useEffect, useState } from "react";
import { readObject } from "./pageData";
import { apiFetch } from "../auth/api";
import { useAuth } from "../auth/AuthContext";
import "./Profile.css";

function AdminUsers() {
  const { user, setCurrentUser } = useAuth();
  const [users, setUsers] = useState([]);
  const [error, setError] = useState("");
  const [message, setMessage] = useState("");
  useEffect(() => { apiFetch("/api/admin/users").then(setUsers).catch((reason) => setError(reason.message)); }, []);
  async function changeRole(target, role) {
    setError(""); setMessage("");
    try {
      const updated = await apiFetch(`/api/admin/users/${encodeURIComponent(target.id)}`, { method: "PUT", body: JSON.stringify({ role }) });
      setUsers((current) => current.map((item) => item.id === updated.id ? updated : item));
      if (updated.id === user.id) setCurrentUser(updated);
      setMessage(`${updated.name}'s role is now ${updated.role}.`);
    } catch (reason) { setError(reason.message); }
  }
  return <section className="page-panel admin-users-panel"><div className="section-heading"><div><span className="page-eyebrow">ACCESS CONTROL</span><h2>Workspace users</h2><p>Assign Admin, Manager, or Employee access to registered accounts.</p></div></div>{error && <p className="page-notice error" role="alert">{error}</p>}{message && <p className="page-notice" role="status">{message}</p>}<div className="page-table-wrap"><table className="page-table"><thead><tr><th>Name</th><th>Email</th><th>Access role</th><th>Update</th></tr></thead><tbody>{users.map((account) => <UserRoleRow key={account.id} account={account} onChange={changeRole} />)}{users.length === 0 && !error && <tr><td colSpan="4">Loading users…</td></tr>}</tbody></table></div><small className="settings-help">New registrations get Employee access. The first registered account is the initial Admin.</small></section>;
}
function UserRoleRow({ account, onChange }) {
  const [role, setRole] = useState(account.role);
  useEffect(() => setRole(account.role), [account.role]);
  return <tr><td><strong>{account.name}</strong></td><td>{account.email}</td><td><select className="page-select" value={role} onChange={(event) => setRole(event.target.value)}>{["Admin", "Manager", "Employee"].map((item) => <option key={item}>{item}</option>)}</select></td><td><button type="button" className="table-link" disabled={role === account.role} onClick={() => onChange(account, role)}>Save role</button></td></tr>;
}
const defaults = { name: "Workspace User", email: "", title: "Resource manager", timezone: "Asia/Kolkata", weekStart: "Monday", emailUpdates: true, capacityAlerts: true, projectDigest: false };

export default function Profile() {
  const { user } = useAuth();
  const [profile, setProfile] = useState(() => readObject("resourceProfile", defaults));
  const [tab, setTab] = useState("Personal information");
  const [saved, setSaved] = useState(false);
  function submit(event) { event.preventDefault(); localStorage.setItem("resourceProfile", JSON.stringify(profile)); setSaved(true); window.setTimeout(() => setSaved(false), 2500); }
  function update(key, value) { setProfile((current) => ({ ...current, [key]: value })); setSaved(false); }
  return <main className="page-shell profile-settings-page"><header className="page-heading"><div><span className="page-eyebrow">ACCOUNT</span><h1>Profile & settings</h1><p>Set your workspace details and planning preferences.</p></div></header>
    {user?.role === "Admin" && <AdminUsers />}
    <section className="profile-card settings-profile-card"><span className="large-avatar">{profile.name.split(/\s+/).slice(0, 2).map((part) => part[0]).join("").toUpperCase() || "U"}</span><div><h2>{profile.name}</h2><p>{profile.title || "Workspace member"}{profile.email ? ` · ${profile.email}` : ""}</p></div></section>
    <section className="page-panel settings-panel"><div className="settings-tabs" role="tablist" aria-label="Profile settings">{["Personal information", "Preferences", "Notifications"].map((item) => <button type="button" role="tab" aria-selected={tab === item} className={tab === item ? "active" : ""} key={item} onClick={() => setTab(item)}>{item}</button>)}</div><form className="page-form" onSubmit={submit}>
      {tab === "Personal information" && <><label>Full name<input className="page-input" value={profile.name} onChange={(e) => update("name", e.target.value)} required maxLength="100" /></label><label>Email address<input className="page-input" type="email" value={profile.email} onChange={(e) => update("email", e.target.value)} maxLength="254" /></label><label className="span-all">Job title<input className="page-input" value={profile.title} onChange={(e) => update("title", e.target.value)} maxLength="100" /></label><p className="settings-help span-all">These details are saved in this browser and are not connected to a user account yet.</p></>}
      {tab === "Preferences" && <><label>Timezone<select className="page-select" value={profile.timezone} onChange={(e) => update("timezone", e.target.value)}>{["Asia/Kolkata", "UTC", "America/Los_Angeles", "America/New_York", "Europe/London", "Asia/Singapore"].map((zone) => <option key={zone}>{zone}</option>)}</select></label><label>Week starts on<select className="page-select" value={profile.weekStart} onChange={(e) => update("weekStart", e.target.value)}><option>Monday</option><option>Sunday</option></select></label><p className="settings-help span-all">Planning preferences are ready for use by future calendar and reporting views.</p></>}
      {tab === "Notifications" && <div className="notification-settings span-all">{[["emailUpdates", "Product updates", "Receive updates about changes to your resource planning workspace."], ["capacityAlerts", "Capacity alerts", "Flag people who approach or exceed their capacity."], ["projectDigest", "Project digest", "Include a summary of active projects in periodic updates."]].map(([key, title, description]) => <label className="notification-option" key={key}><span><strong>{title}</strong><small>{description}</small></span><input type="checkbox" checked={Boolean(profile[key])} onChange={(e) => update(key, e.target.checked)} /></label>)}<p className="settings-help">Notification preferences are stored locally. No email notifications are sent yet.</p></div>}
      <div className="settings-save-row span-all">{saved && <span role="status">Settings saved.</span>}<button className="primary-action" type="submit">Save settings</button></div>
    </form></section>
  </main>;
}
