﻿import { NavLink, useNavigate } from "react-router-dom";
import { useAuth } from "../auth/AuthContext";
import "./WorkspaceLayout.css";

const links = [
  ["/dashboard", "Dashboard", "Overview", ["Admin", "Manager"]],
  ["/employees", "Employees", "People", ["Admin", "Manager"]],
  ["/projects", "Projects", "Delivery", ["Admin", "Manager"]],
  ["/resource-matching", "Resource matching", "Find talent", ["Admin", "Manager"]],
  ["/allocations", "Allocations", "Assignments", ["Admin", "Manager"]],
  ["/workload", "Workload", "Capacity", ["Admin", "Manager", "Employee"]],
  ["/reports", "Reports", "Insights", ["Admin", "Manager"]],
  ["/employee-profile", "My profile", "Employee details", ["Employee"]],
];
export default function WorkspaceLayout({ children }) {
  const { user, logout } = useAuth();
  const navigate = useNavigate();
  const visibleLinks = links.filter(([, , , roles]) => roles.includes(user?.role));
  function signOut() { logout(); navigate("/login", { replace: true }); }
  return <div className="workspace-shell">
    <aside className="workspace-sidebar">
      <NavLink to={user?.role === "Employee" ? "/employee-profile" : "/dashboard"} className="workspace-brand"><span className="brand-mark">R</span><span>Resource<span className="brand-light">Flow</span><small>TEAM PLANNING</small></span></NavLink>
      <span className="nav-label">WORKSPACE</span>
      <nav aria-label="Main navigation">{visibleLinks.map(([to, label, hint]) => <NavLink key={to} to={to} className={({ isActive }) => `workspace-nav-link${isActive ? " active" : ""}`}><span>{label}</span><small>{hint}</small></NavLink>)}</nav>
      <div className="sidebar-footer"><span className="sidebar-avatar">{(user?.name || "U").split(/\s+/).slice(0, 2).map((part) => part[0]).join("").toUpperCase()}</span><div><strong>{user?.name}</strong><small>{user?.role}</small></div><NavLink to="/profile" aria-label="Profile and settings" title="Profile and settings">Profile</NavLink></div>
    </aside>
    <div className="workspace-main"><header className="workspace-topbar"><span>Resource planning workspace</span><div className="topbar-actions"><NavLink to="/profile" className="topbar-profile"><span className="profile-dot">{(user?.name || "U")[0].toUpperCase()}</span> {user?.name} · {user?.role}</NavLink><button type="button" className="logout-button" onClick={signOut}>Log out</button></div></header><div className="workspace-page">{children}</div></div>
  </div>;
}
