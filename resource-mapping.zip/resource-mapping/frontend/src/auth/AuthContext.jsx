﻿import { createContext, useContext, useEffect, useMemo, useState } from "react";
import { apiFetch } from "./api";

const AuthContext = createContext(null);
export function AuthProvider({ children }) {
  const [user, setUser] = useState(() => { try { return JSON.parse(localStorage.getItem("authUser") || "null"); } catch { return null; } });
  const [loading, setLoading] = useState(Boolean(localStorage.getItem("authToken")));
  useEffect(() => {
    let active = true;
    const token = localStorage.getItem("authToken");
    if (!token) { setLoading(false); setUser(null); return undefined; }
    apiFetch("/api/auth/me").then((result) => { if (active) { setUser(result); localStorage.setItem("authUser", JSON.stringify(result)); } }).catch(() => { if (active) { localStorage.removeItem("authToken"); localStorage.removeItem("authUser"); setUser(null); } }).finally(() => { if (active) setLoading(false); });
    return () => { active = false; };
  }, []);
  useEffect(() => {
    const expire = () => { localStorage.removeItem("authToken"); localStorage.removeItem("authUser"); setUser(null); };
    window.addEventListener("auth:expired", expire);
    return () => window.removeEventListener("auth:expired", expire);
  }, []);
  const value = useMemo(() => ({ user, loading, login(data) { localStorage.setItem("authToken", data.token); localStorage.setItem("authUser", JSON.stringify(data.user)); setUser(data.user); }, logout() { localStorage.removeItem("authToken"); localStorage.removeItem("authUser"); setUser(null); }, setCurrentUser(next) { localStorage.setItem("authUser", JSON.stringify(next)); setUser(next); } }), [user, loading]);
  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>;
}
export function useAuth() { const value = useContext(AuthContext); if (!value) throw new Error("useAuth must be used within AuthProvider"); return value; }
