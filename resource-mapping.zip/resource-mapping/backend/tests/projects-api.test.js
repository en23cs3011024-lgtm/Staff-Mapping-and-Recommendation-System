import assert from "node:assert/strict";
import { spawn } from "node:child_process";
import { once } from "node:events";
import { createServer as createTcpServer } from "node:net";
import { mkdtemp, rm } from "node:fs/promises";
import { tmpdir } from "node:os";
import { dirname, join } from "node:path";
import { fileURLToPath } from "node:url";
import test from "node:test";

const backendDirectory = dirname(dirname(fileURLToPath(import.meta.url)));
const serverPath = join(backendDirectory, "server.js");

async function freePort() {
  const socket = createTcpServer();
  socket.listen(0, "127.0.0.1");
  await once(socket, "listening");
  const { port } = socket.address();
  await new Promise((resolve, reject) => socket.close((error) => error ? reject(error) : resolve()));
  return port;
}

test("project CRUD persists to SQLite and returns useful errors", async (t) => {
  const temporaryDirectory = await mkdtemp(join(tmpdir(), "resource-mapping-api-"));
  const port = await freePort();
  const child = spawn(process.execPath, [serverPath], {
    env: { ...process.env, PORT: String(port), EMPLOYEES_DB_FILE: join(temporaryDirectory, "test.sqlite") },
    stdio: "ignore",
  });
  const baseUrl = `http://127.0.0.1:${port}`;
  t.after(async () => {
    if (child.exitCode === null) {
      child.kill();
      await once(child, "exit");
    }
    await rm(temporaryDirectory, { recursive: true, force: true });
  });

  let ready = false;
  for (let attempt = 0; attempt < 80; attempt += 1) {
    if (child.exitCode !== null) throw new Error(`API process exited early with code ${child.exitCode}`);
    try {
      const response = await fetch(`${baseUrl}/api/projects`);
      if (response.ok) { ready = true; break; }
    } catch {}
    await new Promise((resolve) => setTimeout(resolve, 50));
  }
  assert.equal(ready, true, "API should start and accept requests");

  const listUrl = `${baseUrl}/api/projects`;
  const emptyList = await fetch(listUrl);
  assert.equal(emptyList.status, 200);
  assert.deepEqual(await emptyList.json(), []);

  const projectPayload = {
    name: "Phase 2 API project",
    client: "Internal",
    description: "CRUD smoke test",
    requiredSkills: ["React", "SQLite"],
    experience: 2,
    teamSize: 3,
    startDate: "2026-10-28",
    endDate: "2026-12-15",
    status: "Planned",
  };
  const createResponse = await fetch(listUrl, { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(projectPayload) });
  assert.equal(createResponse.status, 201);
  const created = await createResponse.json();
  assert.ok(created.id);
  assert.equal(created.name, projectPayload.name);
  assert.deepEqual(created.requiredSkills, projectPayload.requiredSkills);
  assert.ok(created.createdAt);

  const duplicateId = await fetch(listUrl, { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ ...projectPayload, id: created.id }) });
  assert.equal(duplicateId.status, 409);
  assert.match((await duplicateId.json()).error, /already exists/i);

  const persistedList = await fetch(listUrl);
  assert.equal(persistedList.status, 200);
  assert.equal((await persistedList.json()).length, 1);

  const updateResponse = await fetch(`${listUrl}/${encodeURIComponent(created.id)}`, {
    method: "PUT",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ ...created, name: "Updated phase 2 project", status: "Active", teamSize: 4 }),
  });
  assert.equal(updateResponse.status, 200);
  const updated = await updateResponse.json();
  assert.equal(updated.id, created.id);
  assert.equal(updated.name, "Updated phase 2 project");
  assert.equal(updated.status, "Active");
  assert.equal(updated.teamSize, 4);
  assert.equal(updated.createdAt, created.createdAt);
  assert.ok(updated.updatedAt >= created.updatedAt);

  const invalidResponse = await fetch(listUrl, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ ...projectPayload, name: "Invalid dates", startDate: "2026-12-10", endDate: "2026-11-01" }),
  });
  assert.equal(invalidResponse.status, 400);
  assert.match((await invalidResponse.json()).error, /End date/);

  const malformedBody = await fetch(listUrl, { method: "POST", headers: { "Content-Type": "application/json" }, body: "{" });
  assert.equal(malformedBody.status, 400);
  assert.match((await malformedBody.json()).error, /valid JSON/i);

  const missingUpdate = await fetch(`${listUrl}/missing-project`, { method: "PUT", headers: { "Content-Type": "application/json" }, body: JSON.stringify(projectPayload) });
  assert.equal(missingUpdate.status, 404);
  const missingDelete = await fetch(`${listUrl}/missing-project`, { method: "DELETE" });
  assert.equal(missingDelete.status, 404);

  const deleteResponse = await fetch(`${listUrl}/${encodeURIComponent(created.id)}`, { method: "DELETE" });
  assert.equal(deleteResponse.status, 204);
  assert.equal((await (await fetch(listUrl)).json()).length, 0);

  const employeeResponse = await fetch(`${baseUrl}/api/employees`);
  assert.equal(employeeResponse.status, 200, "existing employee API remains available");
  const createdEmployee = await fetch(`${baseUrl}/api/employees`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ name: "Smoke Test User", employeeId: "SMOKE-001", email: "smoke@example.test" }),
  });
  assert.equal(createdEmployee.status, 201, "existing employee create endpoint still accepts request bodies");
  const employee = await createdEmployee.json();
  assert.equal((await fetch(`${baseUrl}/api/employees/${encodeURIComponent(employee.id)}`, { method: "DELETE" })).status, 204);
});
