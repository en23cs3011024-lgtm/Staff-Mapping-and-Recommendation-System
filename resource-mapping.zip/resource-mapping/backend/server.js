import { createServer } from "node:http";
import { createHmac, randomBytes, scryptSync, timingSafeEqual } from "node:crypto";
import { mkdirSync } from "node:fs";
import { dirname, join } from "node:path";
import { fileURLToPath } from "node:url";
import { DatabaseSync } from "node:sqlite";

const here = dirname(fileURLToPath(import.meta.url));
const dbPath = process.env.EMPLOYEES_DB_FILE || join(here, "data", "employees.sqlite");
const port = Number(process.env.PORT || 3001);
mkdirSync(dirname(dbPath), { recursive: true });

const database = new DatabaseSync(dbPath);
database.exec(`
  PRAGMA journal_mode = WAL;
  CREATE TABLE IF NOT EXISTS employees (
    id TEXT PRIMARY KEY,
    employee_id TEXT NOT NULL COLLATE NOCASE UNIQUE,
    email TEXT NOT NULL COLLATE NOCASE UNIQUE,
    profile TEXT NOT NULL
  );
  CREATE TABLE IF NOT EXISTS projects (
    id TEXT PRIMARY KEY,
    name TEXT NOT NULL COLLATE NOCASE,
    profile TEXT NOT NULL,
    created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
  );
  CREATE TABLE IF NOT EXISTS users (id TEXT PRIMARY KEY, email TEXT NOT NULL COLLATE NOCASE UNIQUE, name TEXT NOT NULL, salt TEXT NOT NULL, password_hash TEXT NOT NULL, role TEXT NOT NULL CHECK (role IN ('Admin', 'Manager', 'Employee')), created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP);
  CREATE TABLE IF NOT EXISTS allocations (id TEXT PRIMARY KEY, employee_id TEXT NOT NULL, project_id TEXT NOT NULL, employee_name TEXT NOT NULL, project_name TEXT NOT NULL, allocation INTEGER NOT NULL, start_date TEXT, end_date TEXT, status TEXT NOT NULL CHECK (status IN ('Active', 'Proposed', 'Completed')), notes TEXT, created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP, updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP);
  CREATE TABLE IF NOT EXISTS app_settings (key TEXT PRIMARY KEY, value TEXT NOT NULL);
`);

const setting = database.prepare("SELECT value FROM app_settings WHERE key = 'jwt_secret'").get();
if (process.env.JWT_SECRET && process.env.JWT_SECRET.length < 32) throw new Error("JWT_SECRET must be at least 32 characters.");
const jwtSecret = process.env.JWT_SECRET || setting?.value || randomBytes(48).toString("base64url");
database.prepare("INSERT OR IGNORE INTO app_settings (key, value) VALUES ('jwt_secret', ?)").run(jwtSecret);
const users = {
  byEmail: database.prepare("SELECT * FROM users WHERE email = ?"),
  byId: database.prepare("SELECT id, email, name, role FROM users WHERE id = ?"),
  count: database.prepare("SELECT COUNT(*) AS count FROM users"),
  insert: database.prepare("INSERT INTO users (id, email, name, salt, password_hash, role) VALUES (?, ?, ?, ?, ?, ?)"),
  list: database.prepare("SELECT id, email, name, role, created_at AS createdAt FROM users ORDER BY name COLLATE NOCASE"),
  changeRole: database.prepare("UPDATE users SET role = ? WHERE id = ?"),
  adminCount: database.prepare("SELECT COUNT(*) AS count FROM users WHERE role = 'Admin'"),
};
function createToken(user) {
  const encode = (value) => Buffer.from(JSON.stringify(value)).toString("base64url");
  const head = encode({ alg: "HS256", typ: "JWT" });
  const body = encode({ sub: user.id, exp: Math.floor(Date.now() / 1000) + 28800 });
  return `${head}.${body}.${createHmac("sha256", jwtSecret).update(`${head}.${body}`).digest("base64url")}`;
}
function auth(request) {
  const token = request.headers.authorization?.match(/^Bearer\s+(.+)$/i)?.[1];
  if (!token) throw new HttpError(401, "Sign in to continue.");
  const [head, body, sig] = token.split(".");
  if (!head || !body || !sig) throw new HttpError(401, "Invalid session. Please sign in again.");
  const expected = createHmac("sha256", jwtSecret).update(`${head}.${body}`).digest();
  const supplied = Buffer.from(sig, "base64url");
  if (expected.length !== supplied.length || !timingSafeEqual(expected, supplied)) throw new HttpError(401, "Invalid session. Please sign in again.");
  let payload;
  try { payload = JSON.parse(Buffer.from(body, "base64url").toString()); } catch { throw new HttpError(401, "Invalid session. Please sign in again."); }
  if (!payload.sub || payload.exp <= Date.now() / 1000) throw new HttpError(401, "Session expired. Please sign in again.");
  const user = users.byId.get(payload.sub);
  if (!user) throw new HttpError(401, "User account no longer exists.");
  return user;
}
function allow(user, roles) { if (!roles.includes(user.role)) throw new HttpError(403, "Your role does not have access to this action."); }
const employeeStatements = {
  list: database.prepare("SELECT profile FROM employees ORDER BY json_extract(profile, '$.name') COLLATE NOCASE"),
  find: database.prepare("SELECT id FROM employees WHERE id = ?"),
  insert: database.prepare("INSERT INTO employees (id, employee_id, email, profile) VALUES (?, ?, ?, ?)"),
  update: database.prepare("UPDATE employees SET employee_id = ?, email = ?, profile = ? WHERE id = ?"),
  remove: database.prepare("DELETE FROM employees WHERE id = ?"),
};
const projectStatements = {
  list: database.prepare("SELECT profile FROM projects ORDER BY json_extract(profile, '$.updatedAt') DESC, name COLLATE NOCASE"),
  find: database.prepare("SELECT id FROM projects WHERE id = ?"),
  insert: database.prepare("INSERT INTO projects (id, name, profile) VALUES (?, ?, ?)"),
  update: database.prepare("UPDATE projects SET name = ?, profile = ? WHERE id = ?"),
  remove: database.prepare("DELETE FROM projects WHERE id = ?"),
};

const allocationStatements = {
  list: database.prepare("SELECT * FROM allocations ORDER BY created_at DESC"),
  find: database.prepare("SELECT * FROM allocations WHERE id = ?"),
  insert: database.prepare("INSERT INTO allocations (id, employee_id, project_id, employee_name, project_name, allocation, start_date, end_date, status, notes) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)"),
  update: database.prepare("UPDATE allocations SET employee_id = ?, project_id = ?, employee_name = ?, project_name = ?, allocation = ?, start_date = ?, end_date = ?, status = ?, notes = ?, updated_at = CURRENT_TIMESTAMP WHERE id = ?"),
  remove: database.prepare("DELETE FROM allocations WHERE id = ?"),
};

function allocationRow(row) {
  if (!row) return null;
  return {
    id: row.id,
    employeeId: row.employee_id,
    projectId: row.project_id,
    employeeName: row.employee_name,
    projectName: row.project_name,
    allocation: row.allocation,
    startDate: row.start_date || "",
    endDate: row.end_date || "",
    status: row.status,
    notes: row.notes || "",
  };
}

class HttpError extends Error {
  constructor(status, message) { super(message); this.status = status; }
}

function send(response, status, body) {
  response.writeHead(status, { "Content-Type": "application/json; charset=utf-8", "Cache-Control": "no-store" });
  response.end(body === undefined ? "" : JSON.stringify(body));
}

async function readBody(request) {
  let body = "";
  for await (const chunk of request) {
    body += chunk;
    if (body.length > 1_000_000) throw new HttpError(413, "Request body is too large.");
  }
  try { return JSON.parse(body || "{}"); }
  catch { throw new HttpError(400, "Request body must be valid JSON."); }
}

function readRows(statement) {
  return statement.all().map((row) => JSON.parse(row.profile));
}

function isUniqueError(error) {
  return /UNIQUE constraint failed/i.test(error.message || "");
}

function validateEmployee(employee) {
  if (!employee || typeof employee !== "object" || Array.isArray(employee)) throw new HttpError(400, "Employee payload must be a JSON object.");
  if (typeof employee.name !== "string" || !employee.name.trim() || typeof employee.employeeId !== "string" || !employee.employeeId.trim() || typeof employee.email !== "string" || !employee.email.trim()) {
    throw new HttpError(400, "Name, employee ID, and email are required.");
  }
  if (!/^\S+@\S+\.\S+$/.test(employee.email.trim())) throw new HttpError(400, "Enter a valid email address.");
}

function validateProject(project) {
  if (!project || typeof project !== "object" || Array.isArray(project)) throw new HttpError(400, "Project payload must be a JSON object.");
  if (typeof project.name !== "string" || !project.name.trim()) throw new HttpError(400, "Project name is required.");
  if (project.name.trim().length > 120) throw new HttpError(400, "Project name must be 120 characters or fewer.");
  if (project.client != null && (typeof project.client !== "string" || project.client.length > 120)) throw new HttpError(400, "Client must be 120 characters or fewer.");
  if (project.description != null && (typeof project.description !== "string" || project.description.length > 1000)) throw new HttpError(400, "Description must be 1,000 characters or fewer.");
  if (project.requiredSkills != null && !Array.isArray(project.requiredSkills)) throw new HttpError(400, "Required skills must be a list.");
  if (Array.isArray(project.requiredSkills) && project.requiredSkills.some((skill) => typeof skill !== "string" || skill.trim().length > 80)) throw new HttpError(400, "Each required skill must be text of 80 characters or fewer.");
  const experience = Number(project.experience ?? 0);
  const teamSize = Number(project.teamSize ?? 1);
  if (!Number.isFinite(experience) || experience < 0 || experience > 80) throw new HttpError(400, "Experience must be between 0 and 80 years.");
  if (!Number.isInteger(teamSize) || teamSize < 1 || teamSize > 500) throw new HttpError(400, "Team size must be a whole number between 1 and 500.");
  if (!["Planned", "Active", "On Hold", "At Risk", "Completed"].includes(project.status || "Planned")) throw new HttpError(400, "Project status is invalid.");
  const datePattern = /^\d{4}-\d{2}-\d{2}$/;
  for (const key of ["startDate", "endDate"]) {
    if (!project[key]) continue;
    const timestamp = Date.parse(`${project[key]}T00:00:00.000Z`);
    if (!datePattern.test(project[key]) || Number.isNaN(timestamp) || new Date(timestamp).toISOString().slice(0, 10) !== project[key]) {
      throw new HttpError(400, `${key === "startDate" ? "Start" : "End"} date must be a valid date.`);
    }
  }
  if (project.startDate && project.endDate && project.endDate < project.startDate) throw new HttpError(400, "End date must be on or after the start date.");
}

function normalizeProject(input, existing = {}) {
  const now = new Date().toISOString();
  return {
    ...existing,
    ...input,
    id: existing.id || input.id || crypto.randomUUID(),
    name: input.name.trim(),
    client: (input.client || "").trim(),
    description: input.description || "",
    requiredSkills: (input.requiredSkills || []).map((skill) => skill.trim()).filter(Boolean),
    experience: Number(input.experience || 0),
    teamSize: Number(input.teamSize || 1),
    status: input.status || "Planned",
    createdAt: existing.createdAt || now,
    updatedAt: now,
  };
}

const server = createServer(async (request, response) => {
  if (!request.url?.startsWith("/api/")) return send(response, 404, { error: "Route not found." });
  try {
const url = new URL(request.url, `http://${request.headers.host || "localhost"}`);

    if (url.pathname === "/api/auth/register" && request.method === "POST") {
      const input = await readBody(request);
      const email = String(input.email || "").trim().toLowerCase();
      const name = String(input.name || "").trim();
      const password = String(input.password || "");
      if (!/^\S+@\S+\.\S+$/.test(email) || email.length > 254) throw new HttpError(400, "Enter a valid email address.");
      if (name.length < 2 || name.length > 100) throw new HttpError(400, "Name must be 2 to 100 characters.");
      if (password.length < 8 || password.length > 128) throw new HttpError(400, "Password must be 8 to 128 characters.");
      const salt = randomBytes(16).toString("hex");
      const role = users.count.get().count === 0 ? "Admin" : "Employee";
      const user = { id: crypto.randomUUID(), email, name, role };
      try {
        users.insert.run(user.id, email, name, salt, scryptSync(password, salt, 64).toString("hex"), role);
        if (role === "Employee") {
          const employeeId = `EMP-${String(Date.now()).slice(-6)}-${randomBytes(2).toString("hex").toUpperCase()}`;
          const profile = {
            id: user.id,
            employeeId,
            name,
            email,
            phone: "",
            department: "",
            designation: "",
            joiningDate: "",
            experience: 0,
            skills: [],
            certifications: [],
            availability: "Available",
            workload: 0,
            projects: 0,
          };
          employeeStatements.insert.run(user.id, employeeId, email, JSON.stringify(profile));
        }
      }
      catch (error) { if (/UNIQUE constraint failed/i.test(error.message)) throw new HttpError(409, "An account with this email already exists."); throw error; }
      return send(response, 201, { token: createToken(user), user });
    }
    if (url.pathname === "/api/auth/login" && request.method === "POST") {
      const input = await readBody(request);
      const user = users.byEmail.get(String(input.email || "").trim().toLowerCase());
      const candidate = scryptSync(String(input.password || ""), user?.salt || "invalid-user-salt", 64);
      if (!user || !timingSafeEqual(candidate, Buffer.from(user.password_hash, "hex")) || input.role !== user.role) throw new HttpError(401, "Email, password, or selected account role is incorrect.");
      const safeUser = { id: user.id, email: user.email, name: user.name, role: user.role };
      return send(response, 200, { token: createToken(safeUser), user: safeUser });
    }
    const user = auth(request);
    if (url.pathname === "/api/auth/me" && request.method === "GET") return send(response, 200, user);
    if (url.pathname === "/api/admin/users" && request.method === "GET") {
      allow(user, ["Admin"]);
      return send(response, 200, users.list.all());
    }
    const roleMatch = url.pathname.match(/^\/api\/admin\/users\/([^/]+)$/);
    if (roleMatch && request.method === "PUT") {
      allow(user, ["Admin"]);
      const targetId = decodeURIComponent(roleMatch[1]);
      const input = await readBody(request);
      if (!["Admin", "Manager", "Employee"].includes(input.role)) throw new HttpError(400, "Choose a valid user role.");
      const target = users.byId.get(targetId);
      if (!target) throw new HttpError(404, "User not found.");
      if (target.role === "Admin" && input.role !== "Admin" && users.adminCount.get().count <= 1) throw new HttpError(400, "The last Admin cannot be demoted.");
      users.changeRole.run(input.role, targetId);
      return send(response, 200, users.byId.get(targetId));
    }

    if (url.pathname === "/api/employees") {
      if (request.method === "GET") {
        if (["Admin", "Manager"].includes(user.role)) return send(response, 200, readRows(employeeStatements.list));
        return send(response, 200, readRows(employeeStatements.list).filter((employee) => employee.email?.toLowerCase() === user.email.toLowerCase()));
      }
      allow(user, ["Admin"]);
      if (request.method === "POST") {
        const employee = await readBody(request);
        validateEmployee(employee);
        const created = { ...employee, id: employee.id || crypto.randomUUID() };
        try { employeeStatements.insert.run(String(created.id), created.employeeId.trim(), created.email.trim().toLowerCase(), JSON.stringify(created)); }
        catch (error) {
          if (isUniqueError(error)) return send(response, 409, { error: /employee_id/i.test(error.message) ? "This employee ID is already in use." : "This email is already registered." });
          throw error;
        }
        return send(response, 201, created);
      }
      return send(response, 405, { error: "Method not allowed." });
    }

    const employeeMatch = url.pathname.match(/^\/api\/employees\/([^/]+)$/);
    if (employeeMatch) {
      const id = decodeURIComponent(employeeMatch[1]);
      const employee = readRows(employeeStatements.list).find((item) => String(item.id) === id);
      if (!employee) return send(response, 404, { error: "Employee not found." });
      if (request.method === "GET") { if (!["Admin", "Manager"].includes(user.role) && employee.email?.toLowerCase() !== user.email.toLowerCase()) throw new HttpError(403, "You can only view your own profile."); return send(response, 200, employee); }
      if (request.method === "PUT") {
        if (user.role !== "Admin" && (user.role !== "Employee" || employee.email?.toLowerCase() !== user.email.toLowerCase())) throw new HttpError(403, "You can only edit your own profile.");
        const update = await readBody(request);
        validateEmployee(update);
        const updated = { ...update, id, email: user.role === "Employee" ? user.email : update.email.trim().toLowerCase() };
        try { employeeStatements.update.run(updated.employeeId.trim(), updated.email.trim().toLowerCase(), JSON.stringify(updated), id); }
        catch (error) {
          if (isUniqueError(error)) return send(response, 409, { error: /employee_id/i.test(error.message) ? "This employee ID is already in use." : "This email is already registered." });
          throw error;
        }
        return send(response, 200, updated);
      }
      if (request.method === "DELETE") {
        allow(user, ["Admin"]);
        employeeStatements.remove.run(id);
        return send(response, 204);
      }
      return send(response, 405, { error: "Method not allowed." });
    }

    if (url.pathname === "/api/projects") {
      if (request.method === "GET") allow(user, ["Admin", "Manager"]);
      else allow(user, ["Admin"]);
      if (request.method === "GET") { allow(user, ["Admin", "Manager"]); return send(response, 200, readRows(projectStatements.list)); }
      if (request.method === "POST") {
        const input = await readBody(request);
        validateProject(input);
        const project = normalizeProject(input);
        try { projectStatements.insert.run(String(project.id), project.name, JSON.stringify(project)); }
        catch (error) { if (isUniqueError(error)) return send(response, 409, { error: "A project with this ID already exists." }); throw error; }
        return send(response, 201, project);
      }
      return send(response, 405, { error: "Method not allowed." });
    }

    const projectMatch = url.pathname.match(/^\/api\/projects\/([^/]+)$/);
    if (projectMatch) {
      const id = decodeURIComponent(projectMatch[1]);
      if (request.method === "GET") allow(user, ["Admin", "Manager"]);
      else allow(user, ["Admin"]);
      if (!projectStatements.find.get(id)) return send(response, 404, { error: "Project not found." });
      if (request.method === "PUT") {
        const input = await readBody(request);
        validateProject(input);
        const existing = readRows(projectStatements.list).find((project) => String(project.id) === id);
        const project = normalizeProject({ ...input, id }, existing);
        try { projectStatements.update.run(project.name, JSON.stringify(project), id); }
        catch (error) { if (isUniqueError(error)) return send(response, 409, { error: "A project with this ID already exists." }); throw error; }
        return send(response, 200, project);
      }
      if (request.method === "DELETE") {
        projectStatements.remove.run(id);
        return send(response, 204);
      }
      return send(response, 405, { error: "Method not allowed." });
    }

    if (url.pathname === "/api/allocations") {
      allow(user, ["Admin", "Manager"]);
      if (request.method === "GET") return send(response, 200, allocationStatements.list.all().map(allocationRow));
      if (request.method === "POST") {
        const input = await readBody(request);
        const allocation = Number(input.allocation);
        if (!input.employeeId || !input.projectId) throw new HttpError(400, "Choose an employee and a project.");
        if (!Number.isInteger(allocation) || allocation < 1 || allocation > 100) throw new HttpError(400, "Allocation must be between 1% and 100%.");
        if (!["Active", "Proposed", "Completed"].includes(input.status || "Active")) throw new HttpError(400, "Allocation status is invalid.");
        if (input.endDate && input.startDate && input.endDate < input.startDate) throw new HttpError(400, "End date must be on or after the start date.");
        const employee = readRows(employeeStatements.list).find((item) => String(item.id) === String(input.employeeId));
        const project = readRows(projectStatements.list).find((item) => String(item.id) === String(input.projectId));
        if (!employee) throw new HttpError(404, "Employee not found.");
        if (!project) throw new HttpError(404, "Project not found.");
        if ((input.status || "Active") === "Active") {
          const existing = allocationStatements.list.all().filter((row) => row.employee_id === String(input.employeeId) && row.status === "Active");
          const assigned = existing.reduce((sum, row) => sum + row.allocation, 0);
          const available = Math.max(0, 100 - (Number(employee.workload) || 0));
          if (assigned + allocation > available) throw new HttpError(400, `${employee.name} has only ${available}% capacity available.`);
        }
        const record = {
          id: crypto.randomUUID(), employeeId: String(input.employeeId), projectId: String(input.projectId),
          employeeName: employee.name, projectName: project.name, allocation,
          startDate: String(input.startDate || ""), endDate: String(input.endDate || ""),
          status: input.status || "Active", notes: String(input.notes || ""),
        };
        allocationStatements.insert.run(record.id, record.employeeId, record.projectId, record.employeeName, record.projectName, record.allocation, record.startDate, record.endDate, record.status, record.notes);
        return send(response, 201, record);
      }
      return send(response, 405, { error: "Method not allowed." });
    }

    const allocationMatch = url.pathname.match(/^\/api\/allocations\/([^/]+)$/);
    if (allocationMatch) {
      allow(user, ["Admin", "Manager"]);
      const id = decodeURIComponent(allocationMatch[1]);
      const existing = allocationStatements.find.get(id);
      if (!existing) throw new HttpError(404, "Allocation not found.");
      if (request.method === "GET") return send(response, 200, allocationRow(existing));
      if (request.method === "PUT") {
        const input = await readBody(request);
        const allocation = Number(input.allocation);
        if (!Number.isInteger(allocation) || allocation < 1 || allocation > 100) throw new HttpError(400, "Allocation must be between 1% and 100%.");
        if (!["Active", "Proposed", "Completed"].includes(input.status || existing.status)) throw new HttpError(400, "Allocation status is invalid.");
        const employee = readRows(employeeStatements.list).find((item) => String(item.id) === String(input.employeeId || existing.employee_id));
        const project = readRows(projectStatements.list).find((item) => String(item.id) === String(input.projectId || existing.project_id));
        if (!employee) throw new HttpError(404, "Employee not found.");
        if (!project) throw new HttpError(404, "Project not found.");
        const status = input.status || existing.status;
        if (status === "Active") {
          const other = allocationStatements.list.all().filter((row) => row.employee_id === employee.id && row.status === "Active" && row.id !== id);
          const assigned = other.reduce((sum, row) => sum + row.allocation, 0);
          const available = Math.max(0, 100 - (Number(employee.workload) || 0));
          if (assigned + allocation > available) throw new HttpError(400, `${employee.name} has only ${available}% capacity available.`);
        }
        const record = {
          id, employeeId: employee.id, projectId: project.id, employeeName: employee.name, projectName: project.name,
          allocation, startDate: String(input.startDate ?? existing.start_date ?? ""), endDate: String(input.endDate ?? existing.end_date ?? ""),
          status, notes: String(input.notes ?? existing.notes ?? ""),
        };
        allocationStatements.update.run(record.employeeId, record.projectId, record.employeeName, record.projectName, record.allocation, record.startDate, record.endDate, record.status, record.notes, id);
        return send(response, 200, record);
      }
      if (request.method === "DELETE") {
        allocationStatements.remove.run(id);
        return send(response, 204);
      }
      return send(response, 405, { error: "Method not allowed." });
    }

    return send(response, 404, { error: "Route not found." });
  } catch (error) {
    return send(response, error.status || 500, { error: error.message || "Internal server error." });
  }
});

server.listen(port, () => console.log(`Resource mapping API listening on http://localhost:${port}; SQLite database: ${dbPath}`));
